#include "MainProcess.h"
#include <Adafruit_MCP4725.h>
#include <Wire.h>
#include "HMI_Command.h"
#include "EEPROM_Function.h"

extern HMI_Command *hmi_cmd;
extern Adafruit_MCP4725 MCP4725;
extern HardwareSerial *cmd_port;
MainDataStruct maindata;
RuntimeStatus runtimedata;

void MainProcess_ReCheckEEPROMValue()
{
	if((maindata.HMI_ID < 0) || (maindata.HMI_ID > 128))
	{
		maindata.HMI_ID = 0;
		runtimedata.UpdateEEPROM = true;
	}
    if((maindata.Voltage_Last < 0) || (maindata.Voltage_Last > 100))
    {
        maindata.Voltage_Last = 0;
        runtimedata.UpdateEEPROM = true;
    }
    if(maindata.CheckVersion != 101001){
        maindata.CheckVersion = 101001;
        for(uint8_t i=0; i<4; i++)
            maindata.Output_Last_HighLow[i] = 0;
        runtimedata.UpdateEEPROM = true;
    }
}
void CheckID()
{
    maindata.HMI_ID = 0;
    for(int i=0; i<4; i++){
        if(digitalRead(ADC_InputPin[i])){
            setbit(maindata.HMI_ID, i);
        }
        else{
            clrbit(maindata.HMI_ID, i);
        }
    }
    cmd_port->println("HMI_ID: " + String(maindata.HMI_ID));
    runtimedata.UpdateEEPROM = true;
}

void MainProcess_Init()
{
	runtimedata.UpdateEEPROM = false;
	MainProcess_ReCheckEEPROMValue();
    CheckID();
    for(uint8_t i=0; i<4; i++){
        digitalWrite(ADC_OutputPin[i], maindata.Output_Last_HighLow[i]);
    }
    SetVoltage(maindata.Voltage_Last);
}

void MainProcess_Task()
{
    if(runtimedata.CheckReceive != -1)
    {
        switch (runtimedata.CheckReceive)
        {
            case 0x00:
                break;
            case 0x01:
                break;
            case 0x02:
                break;
            case 0x03:
                break;
            case 0x04:
                break;
        }
        runtimedata.CheckReceive = -1;
    }
}
void SetVoltage(uint8_t value)
{
    float OUT_K = value*40.96;
    if (OUT_K > 4095)
    {
        OUT_K=4095;
    }
    MCP4725.setVoltage(OUT_K, false);//輸出電壓回復到上一次狀態
}
void buzzerPlay(int playMS)
{
  digitalWrite(BUZZ, HIGH);
  delay(playMS);
  digitalWrite(BUZZ, LOW);
}
