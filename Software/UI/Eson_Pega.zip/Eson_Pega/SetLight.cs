﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eson_Pega
{
    public partial class SetLight : Form
    {
        List<string> LightTube_Type = new List<string>
        {
            "D65 10Lux",
            "D65 20Lux",
            "D65 80Lux",
            "D65 150Lux",
            "D65 800Lux",
            "D65 1000Lux",

            "CWF 20Lux",
            "CWF 320Lux",
            "CWF 1000Lux",

            "TL84 20Lux",
            "TL84 320Lux",
            "TL84 1000Lux",

            "U30 20Lux",
            "U30 320Lux",
            "U30 1000Lux"
        };

        List<string> LightBulb_Type = new List<string>
        {
            "A 50Lux",
            "A 150Lux",
            "A 320Lux",
            "A 450Lux",
            "A 500Lux",
            "A 1000Lux",

            "HZ 1000Lux",
        };
        public SetLight(string Light)
        {
            InitializeComponent();

            if (LightBulb_Type.Contains(Light))
            {
                lb_panel_Init(Light);
            }
            else if(LightTube_Type.Contains(Light))
            {
                lt_panel_Init(Light);
            }
        }

        private void lt_panel_Init(string type)
        {
            LightTube lt = new LightTube(type);
            lt.Show();
            LightSwitch_panel.Controls.Clear();
            LightSwitch_panel.Controls.Add(lt);
        }

        private void lb_panel_Init(string type)
        {
            LightBulb lb = new LightBulb(type);
            lb.Show();
            LightSwitch_panel.Controls.Clear();
            LightSwitch_panel.Controls.Add(lb);
        }

        private void SetLight_Load(object sender, EventArgs e)
        {

        }

    }
}
