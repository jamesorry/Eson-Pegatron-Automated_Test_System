﻿
namespace Eson_Pega
{
    partial class main
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.GroupBox A_groupBox;
            System.Windows.Forms.GroupBox groupBox2;
            System.Windows.Forms.GroupBox groupBox3;
            System.Windows.Forms.GroupBox groupBox4;
            System.Windows.Forms.GroupBox groupBox5;
            System.Windows.Forms.GroupBox groupBox6;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.button6 = new System.Windows.Forms.Button();
            this.button = new System.Windows.Forms.Button();
            this.AMax_button = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.A150_button = new System.Windows.Forms.Button();
            this.A320_button = new System.Windows.Forms.Button();
            this.A500_button = new System.Windows.Forms.Button();
            this.A50_button = new System.Windows.Forms.Button();
            this.A450_button5 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.CWFMax_button = new System.Windows.Forms.Button();
            this.CWF320_button = new System.Windows.Forms.Button();
            this.CWF20_button = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.D65_Max_button = new System.Windows.Forms.Button();
            this.D65_150_button = new System.Windows.Forms.Button();
            this.D65_80_button = new System.Windows.Forms.Button();
            this.D65_20_button = new System.Windows.Forms.Button();
            this.D65_800_button = new System.Windows.Forms.Button();
            this.D65_10_button = new System.Windows.Forms.Button();
            this.U30_Max_button = new System.Windows.Forms.Button();
            this.U30_320_button = new System.Windows.Forms.Button();
            this.U30_20_button = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.TL84_Max_button = new System.Windows.Forms.Button();
            this.TL84_320_button = new System.Windows.Forms.Button();
            this.TL84_20_button = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.HZ_Max_button = new System.Windows.Forms.Button();
            this.All_0_button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Refresh_button = new System.Windows.Forms.Button();
            this.COM_comboBox = new System.Windows.Forms.ComboBox();
            this.connect_button = new System.Windows.Forms.Button();
            this.debug_button = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Slide_groupBox = new System.Windows.Forms.GroupBox();
            this.setX_maskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.getX_button = new System.Windows.Forms.Button();
            this.setX_button = new System.Windows.Forms.Button();
            this.getX_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.stop_button = new System.Windows.Forms.Button();
            this.go_home_button = new System.Windows.Forms.Button();
            this.search_home_button = new System.Windows.Forms.Button();
            this.SetLight_groupBox = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            A_groupBox = new System.Windows.Forms.GroupBox();
            groupBox2 = new System.Windows.Forms.GroupBox();
            groupBox3 = new System.Windows.Forms.GroupBox();
            groupBox4 = new System.Windows.Forms.GroupBox();
            groupBox5 = new System.Windows.Forms.GroupBox();
            groupBox6 = new System.Windows.Forms.GroupBox();
            A_groupBox.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Slide_groupBox.SuspendLayout();
            this.SetLight_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // A_groupBox
            // 
            A_groupBox.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            A_groupBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            A_groupBox.Controls.Add(this.button6);
            A_groupBox.Controls.Add(this.button);
            A_groupBox.Controls.Add(this.AMax_button);
            A_groupBox.Controls.Add(this.button2);
            A_groupBox.Controls.Add(this.A150_button);
            A_groupBox.Controls.Add(this.A320_button);
            A_groupBox.Controls.Add(this.A500_button);
            A_groupBox.Controls.Add(this.A50_button);
            A_groupBox.Controls.Add(this.A450_button5);
            A_groupBox.Font = new System.Drawing.Font("微軟正黑體", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            A_groupBox.Location = new System.Drawing.Point(240, 53);
            A_groupBox.Name = "A_groupBox";
            A_groupBox.Size = new System.Drawing.Size(317, 819);
            A_groupBox.TabIndex = 34;
            A_groupBox.TabStop = false;
            A_groupBox.Text = "A";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(7, 731);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(303, 74);
            this.button6.TabIndex = 48;
            this.button6.Text = "Backup 2";
            this.button6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button
            // 
            this.button.Location = new System.Drawing.Point(7, 649);
            this.button.Margin = new System.Windows.Forms.Padding(4);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(303, 74);
            this.button.TabIndex = 47;
            this.button.Text = "Backup 1";
            this.button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button.UseVisualStyleBackColor = true;
            // 
            // AMax_button
            // 
            this.AMax_button.Location = new System.Drawing.Point(7, 485);
            this.AMax_button.Margin = new System.Windows.Forms.Padding(4);
            this.AMax_button.Name = "AMax_button";
            this.AMax_button.Size = new System.Drawing.Size(303, 74);
            this.AMax_button.TabIndex = 46;
            this.AMax_button.Text = "Max Lux";
            this.AMax_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.AMax_button.UseVisualStyleBackColor = true;
            this.AMax_button.Click += new System.EventHandler(this.AMax_button_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(7, 488);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(303, 74);
            this.button2.TabIndex = 45;
            this.button2.Text = "Max Lux";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // A150_button
            // 
            this.A150_button.Location = new System.Drawing.Point(7, 160);
            this.A150_button.Margin = new System.Windows.Forms.Padding(4);
            this.A150_button.Name = "A150_button";
            this.A150_button.Size = new System.Drawing.Size(303, 74);
            this.A150_button.TabIndex = 44;
            this.A150_button.Text = "150 Lux";
            this.A150_button.UseVisualStyleBackColor = true;
            this.A150_button.Click += new System.EventHandler(this.A150_button_Click);
            // 
            // A320_button
            // 
            this.A320_button.Location = new System.Drawing.Point(7, 242);
            this.A320_button.Margin = new System.Windows.Forms.Padding(4);
            this.A320_button.Name = "A320_button";
            this.A320_button.Size = new System.Drawing.Size(303, 74);
            this.A320_button.TabIndex = 43;
            this.A320_button.Text = "320 Lux";
            this.A320_button.UseVisualStyleBackColor = true;
            this.A320_button.Click += new System.EventHandler(this.A320_button_Click);
            // 
            // A500_button
            // 
            this.A500_button.Location = new System.Drawing.Point(7, 406);
            this.A500_button.Margin = new System.Windows.Forms.Padding(4);
            this.A500_button.Name = "A500_button";
            this.A500_button.Size = new System.Drawing.Size(303, 74);
            this.A500_button.TabIndex = 42;
            this.A500_button.Text = "500 Lux";
            this.A500_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.A500_button.UseVisualStyleBackColor = true;
            this.A500_button.Click += new System.EventHandler(this.A500_button_Click);
            // 
            // A50_button
            // 
            this.A50_button.Location = new System.Drawing.Point(7, 78);
            this.A50_button.Margin = new System.Windows.Forms.Padding(4);
            this.A50_button.Name = "A50_button";
            this.A50_button.Size = new System.Drawing.Size(303, 74);
            this.A50_button.TabIndex = 41;
            this.A50_button.Text = "50 Lux";
            this.A50_button.UseVisualStyleBackColor = true;
            this.A50_button.Click += new System.EventHandler(this.A50_button_Click);
            // 
            // A450_button5
            // 
            this.A450_button5.Location = new System.Drawing.Point(7, 324);
            this.A450_button5.Margin = new System.Windows.Forms.Padding(4);
            this.A450_button5.Name = "A450_button5";
            this.A450_button5.Size = new System.Drawing.Size(303, 74);
            this.A450_button5.TabIndex = 39;
            this.A450_button5.Text = "450 Lux";
            this.A450_button5.UseVisualStyleBackColor = true;
            this.A450_button5.Click += new System.EventHandler(this.A450_button5_Click);
            // 
            // groupBox2
            // 
            groupBox2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            groupBox2.Controls.Add(this.button11);
            groupBox2.Controls.Add(this.button12);
            groupBox2.Controls.Add(this.CWFMax_button);
            groupBox2.Controls.Add(this.CWF320_button);
            groupBox2.Controls.Add(this.CWF20_button);
            groupBox2.Font = new System.Drawing.Font("微軟正黑體", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            groupBox2.Location = new System.Drawing.Point(563, 53);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new System.Drawing.Size(317, 819);
            groupBox2.TabIndex = 35;
            groupBox2.TabStop = false;
            groupBox2.Text = "CWF";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(7, 731);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(303, 74);
            this.button11.TabIndex = 48;
            this.button11.Text = "Backup 2";
            this.button11.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(7, 649);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(303, 74);
            this.button12.TabIndex = 47;
            this.button12.Text = "Backup 1";
            this.button12.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // CWFMax_button
            // 
            this.CWFMax_button.Location = new System.Drawing.Point(7, 243);
            this.CWFMax_button.Margin = new System.Windows.Forms.Padding(4);
            this.CWFMax_button.Name = "CWFMax_button";
            this.CWFMax_button.Size = new System.Drawing.Size(303, 74);
            this.CWFMax_button.TabIndex = 46;
            this.CWFMax_button.Text = "Max Lux";
            this.CWFMax_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CWFMax_button.UseVisualStyleBackColor = true;
            this.CWFMax_button.Click += new System.EventHandler(this.CWFMax_button_Click);
            // 
            // CWF320_button
            // 
            this.CWF320_button.Location = new System.Drawing.Point(7, 160);
            this.CWF320_button.Margin = new System.Windows.Forms.Padding(4);
            this.CWF320_button.Name = "CWF320_button";
            this.CWF320_button.Size = new System.Drawing.Size(303, 74);
            this.CWF320_button.TabIndex = 43;
            this.CWF320_button.Text = "320 Lux";
            this.CWF320_button.UseVisualStyleBackColor = true;
            this.CWF320_button.Click += new System.EventHandler(this.CWF320_button_Click);
            // 
            // CWF20_button
            // 
            this.CWF20_button.Location = new System.Drawing.Point(7, 78);
            this.CWF20_button.Margin = new System.Windows.Forms.Padding(4);
            this.CWF20_button.Name = "CWF20_button";
            this.CWF20_button.Size = new System.Drawing.Size(303, 74);
            this.CWF20_button.TabIndex = 35;
            this.CWF20_button.Text = "20 Lux";
            this.CWF20_button.UseVisualStyleBackColor = true;
            this.CWF20_button.Click += new System.EventHandler(this.CWF20_button_Click);
            // 
            // groupBox3
            // 
            groupBox3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            groupBox3.Controls.Add(this.button21);
            groupBox3.Controls.Add(this.button22);
            groupBox3.Controls.Add(this.D65_Max_button);
            groupBox3.Controls.Add(this.D65_150_button);
            groupBox3.Controls.Add(this.D65_80_button);
            groupBox3.Controls.Add(this.D65_20_button);
            groupBox3.Controls.Add(this.D65_800_button);
            groupBox3.Controls.Add(this.D65_10_button);
            groupBox3.Font = new System.Drawing.Font("微軟正黑體", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            groupBox3.Location = new System.Drawing.Point(886, 53);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new System.Drawing.Size(317, 819);
            groupBox3.TabIndex = 36;
            groupBox3.TabStop = false;
            groupBox3.Text = "D65";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(7, 731);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(303, 74);
            this.button21.TabIndex = 48;
            this.button21.Text = "Backup 2";
            this.button21.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(7, 649);
            this.button22.Margin = new System.Windows.Forms.Padding(4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(303, 74);
            this.button22.TabIndex = 47;
            this.button22.Text = "Backup 1";
            this.button22.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button22.UseVisualStyleBackColor = true;
            // 
            // D65_Max_button
            // 
            this.D65_Max_button.Location = new System.Drawing.Point(7, 488);
            this.D65_Max_button.Margin = new System.Windows.Forms.Padding(4);
            this.D65_Max_button.Name = "D65_Max_button";
            this.D65_Max_button.Size = new System.Drawing.Size(303, 74);
            this.D65_Max_button.TabIndex = 46;
            this.D65_Max_button.Text = "Max Lux";
            this.D65_Max_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.D65_Max_button.UseVisualStyleBackColor = true;
            this.D65_Max_button.Click += new System.EventHandler(this.D65_Max_button_Click);
            // 
            // D65_150_button
            // 
            this.D65_150_button.Location = new System.Drawing.Point(7, 324);
            this.D65_150_button.Margin = new System.Windows.Forms.Padding(4);
            this.D65_150_button.Name = "D65_150_button";
            this.D65_150_button.Size = new System.Drawing.Size(303, 74);
            this.D65_150_button.TabIndex = 44;
            this.D65_150_button.Text = "150 Lux";
            this.D65_150_button.UseVisualStyleBackColor = true;
            this.D65_150_button.Click += new System.EventHandler(this.D65_150_button_Click);
            // 
            // D65_80_button
            // 
            this.D65_80_button.Location = new System.Drawing.Point(7, 242);
            this.D65_80_button.Margin = new System.Windows.Forms.Padding(4);
            this.D65_80_button.Name = "D65_80_button";
            this.D65_80_button.Size = new System.Drawing.Size(303, 74);
            this.D65_80_button.TabIndex = 43;
            this.D65_80_button.Text = "80 Lux";
            this.D65_80_button.UseVisualStyleBackColor = true;
            this.D65_80_button.Click += new System.EventHandler(this.D65_80_button_Click);
            // 
            // D65_20_button
            // 
            this.D65_20_button.Location = new System.Drawing.Point(7, 160);
            this.D65_20_button.Margin = new System.Windows.Forms.Padding(4);
            this.D65_20_button.Name = "D65_20_button";
            this.D65_20_button.Size = new System.Drawing.Size(303, 74);
            this.D65_20_button.TabIndex = 41;
            this.D65_20_button.Text = "20 Lux";
            this.D65_20_button.UseVisualStyleBackColor = true;
            this.D65_20_button.Click += new System.EventHandler(this.D65_20_button_Click);
            // 
            // D65_800_button
            // 
            this.D65_800_button.Location = new System.Drawing.Point(7, 406);
            this.D65_800_button.Margin = new System.Windows.Forms.Padding(4);
            this.D65_800_button.Name = "D65_800_button";
            this.D65_800_button.Size = new System.Drawing.Size(303, 74);
            this.D65_800_button.TabIndex = 39;
            this.D65_800_button.Text = "800 Lux";
            this.D65_800_button.UseVisualStyleBackColor = true;
            this.D65_800_button.Click += new System.EventHandler(this.D65_800_button_Click);
            // 
            // D65_10_button
            // 
            this.D65_10_button.Location = new System.Drawing.Point(7, 78);
            this.D65_10_button.Margin = new System.Windows.Forms.Padding(4);
            this.D65_10_button.Name = "D65_10_button";
            this.D65_10_button.Size = new System.Drawing.Size(303, 74);
            this.D65_10_button.TabIndex = 35;
            this.D65_10_button.Text = "10 Lux";
            this.D65_10_button.UseVisualStyleBackColor = true;
            this.D65_10_button.Click += new System.EventHandler(this.D65_10_button_Click);
            // 
            // groupBox4
            // 
            groupBox4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            groupBox4.Controls.Add(this.U30_Max_button);
            groupBox4.Controls.Add(this.U30_320_button);
            groupBox4.Controls.Add(this.U30_20_button);
            groupBox4.Controls.Add(this.button31);
            groupBox4.Controls.Add(this.button32);
            groupBox4.Font = new System.Drawing.Font("微軟正黑體", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            groupBox4.Location = new System.Drawing.Point(1855, 53);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new System.Drawing.Size(317, 819);
            groupBox4.TabIndex = 37;
            groupBox4.TabStop = false;
            groupBox4.Text = "U30";
            // 
            // U30_Max_button
            // 
            this.U30_Max_button.Location = new System.Drawing.Point(7, 244);
            this.U30_Max_button.Margin = new System.Windows.Forms.Padding(4);
            this.U30_Max_button.Name = "U30_Max_button";
            this.U30_Max_button.Size = new System.Drawing.Size(303, 74);
            this.U30_Max_button.TabIndex = 51;
            this.U30_Max_button.Text = "Max Lux";
            this.U30_Max_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.U30_Max_button.UseVisualStyleBackColor = true;
            this.U30_Max_button.Click += new System.EventHandler(this.U30_Max_button_Click);
            // 
            // U30_320_button
            // 
            this.U30_320_button.Location = new System.Drawing.Point(7, 161);
            this.U30_320_button.Margin = new System.Windows.Forms.Padding(4);
            this.U30_320_button.Name = "U30_320_button";
            this.U30_320_button.Size = new System.Drawing.Size(303, 74);
            this.U30_320_button.TabIndex = 50;
            this.U30_320_button.Text = "320 Lux";
            this.U30_320_button.UseVisualStyleBackColor = true;
            this.U30_320_button.Click += new System.EventHandler(this.U30_320_button_Click);
            // 
            // U30_20_button
            // 
            this.U30_20_button.Location = new System.Drawing.Point(7, 79);
            this.U30_20_button.Margin = new System.Windows.Forms.Padding(4);
            this.U30_20_button.Name = "U30_20_button";
            this.U30_20_button.Size = new System.Drawing.Size(303, 74);
            this.U30_20_button.TabIndex = 49;
            this.U30_20_button.Text = "20 Lux";
            this.U30_20_button.UseVisualStyleBackColor = true;
            this.U30_20_button.Click += new System.EventHandler(this.U30_20_button_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(7, 731);
            this.button31.Margin = new System.Windows.Forms.Padding(4);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(303, 74);
            this.button31.TabIndex = 48;
            this.button31.Text = "Backup 2";
            this.button31.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(7, 649);
            this.button32.Margin = new System.Windows.Forms.Padding(4);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(303, 74);
            this.button32.TabIndex = 47;
            this.button32.Text = "Backup 1";
            this.button32.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button32.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            groupBox5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            groupBox5.Controls.Add(this.TL84_Max_button);
            groupBox5.Controls.Add(this.TL84_320_button);
            groupBox5.Controls.Add(this.TL84_20_button);
            groupBox5.Controls.Add(this.button41);
            groupBox5.Controls.Add(this.button42);
            groupBox5.Font = new System.Drawing.Font("微軟正黑體", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            groupBox5.Location = new System.Drawing.Point(1532, 53);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new System.Drawing.Size(317, 819);
            groupBox5.TabIndex = 38;
            groupBox5.TabStop = false;
            groupBox5.Text = "TL84";
            // 
            // TL84_Max_button
            // 
            this.TL84_Max_button.Location = new System.Drawing.Point(7, 244);
            this.TL84_Max_button.Margin = new System.Windows.Forms.Padding(4);
            this.TL84_Max_button.Name = "TL84_Max_button";
            this.TL84_Max_button.Size = new System.Drawing.Size(303, 74);
            this.TL84_Max_button.TabIndex = 51;
            this.TL84_Max_button.Text = "Max Lux";
            this.TL84_Max_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.TL84_Max_button.UseVisualStyleBackColor = true;
            this.TL84_Max_button.Click += new System.EventHandler(this.TL84_Max_button_Click);
            // 
            // TL84_320_button
            // 
            this.TL84_320_button.Location = new System.Drawing.Point(7, 161);
            this.TL84_320_button.Margin = new System.Windows.Forms.Padding(4);
            this.TL84_320_button.Name = "TL84_320_button";
            this.TL84_320_button.Size = new System.Drawing.Size(303, 74);
            this.TL84_320_button.TabIndex = 50;
            this.TL84_320_button.Text = "320 Lux";
            this.TL84_320_button.UseVisualStyleBackColor = true;
            this.TL84_320_button.Click += new System.EventHandler(this.TL84_320_button_Click);
            // 
            // TL84_20_button
            // 
            this.TL84_20_button.Location = new System.Drawing.Point(7, 79);
            this.TL84_20_button.Margin = new System.Windows.Forms.Padding(4);
            this.TL84_20_button.Name = "TL84_20_button";
            this.TL84_20_button.Size = new System.Drawing.Size(303, 74);
            this.TL84_20_button.TabIndex = 49;
            this.TL84_20_button.Text = "20 Lux";
            this.TL84_20_button.UseVisualStyleBackColor = true;
            this.TL84_20_button.Click += new System.EventHandler(this.TL84_20_button_Click);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(7, 731);
            this.button41.Margin = new System.Windows.Forms.Padding(4);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(303, 74);
            this.button41.TabIndex = 48;
            this.button41.Text = "Backup 2";
            this.button41.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(7, 649);
            this.button42.Margin = new System.Windows.Forms.Padding(4);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(303, 74);
            this.button42.TabIndex = 47;
            this.button42.Text = "Backup 1";
            this.button42.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button42.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            groupBox6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            groupBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            groupBox6.Controls.Add(this.button51);
            groupBox6.Controls.Add(this.button52);
            groupBox6.Controls.Add(this.HZ_Max_button);
            groupBox6.Font = new System.Drawing.Font("微軟正黑體", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            groupBox6.Location = new System.Drawing.Point(1209, 53);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new System.Drawing.Size(317, 819);
            groupBox6.TabIndex = 39;
            groupBox6.TabStop = false;
            groupBox6.Text = "HZ";
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(7, 731);
            this.button51.Margin = new System.Windows.Forms.Padding(4);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(303, 74);
            this.button51.TabIndex = 48;
            this.button51.Text = "Backup 2";
            this.button51.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(7, 649);
            this.button52.Margin = new System.Windows.Forms.Padding(4);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(303, 74);
            this.button52.TabIndex = 47;
            this.button52.Text = "Backup 1";
            this.button52.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button52.UseVisualStyleBackColor = true;
            // 
            // HZ_Max_button
            // 
            this.HZ_Max_button.Location = new System.Drawing.Point(7, 79);
            this.HZ_Max_button.Margin = new System.Windows.Forms.Padding(4);
            this.HZ_Max_button.Name = "HZ_Max_button";
            this.HZ_Max_button.Size = new System.Drawing.Size(303, 74);
            this.HZ_Max_button.TabIndex = 46;
            this.HZ_Max_button.Text = "Max Lux";
            this.HZ_Max_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.HZ_Max_button.UseVisualStyleBackColor = true;
            this.HZ_Max_button.Click += new System.EventHandler(this.HZ_Max_button_Click);
            // 
            // All_0_button
            // 
            this.All_0_button.Font = new System.Drawing.Font("微軟正黑體", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.All_0_button.Location = new System.Drawing.Point(15, 54);
            this.All_0_button.Margin = new System.Windows.Forms.Padding(4);
            this.All_0_button.Name = "All_0_button";
            this.All_0_button.Size = new System.Drawing.Size(218, 74);
            this.All_0_button.TabIndex = 35;
            this.All_0_button.Text = "0 Lux";
            this.All_0_button.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.Refresh_button);
            this.groupBox1.Controls.Add(this.COM_comboBox);
            this.groupBox1.Controls.Add(this.connect_button);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(696, 146);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "USB連線";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(15, 62);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(204, 54);
            this.label8.TabIndex = 20;
            this.label8.Text = "ComPort";
            // 
            // Refresh_button
            // 
            this.Refresh_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Refresh_button.BackgroundImage")));
            this.Refresh_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Refresh_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Refresh_button.Location = new System.Drawing.Point(444, 63);
            this.Refresh_button.Margin = new System.Windows.Forms.Padding(4);
            this.Refresh_button.Name = "Refresh_button";
            this.Refresh_button.Size = new System.Drawing.Size(69, 59);
            this.Refresh_button.TabIndex = 5;
            this.Refresh_button.UseVisualStyleBackColor = true;
            this.Refresh_button.Click += new System.EventHandler(this.Refresh_button_Click);
            // 
            // COM_comboBox
            // 
            this.COM_comboBox.Font = new System.Drawing.Font("新細明體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.COM_comboBox.FormattingEnabled = true;
            this.COM_comboBox.IntegralHeight = false;
            this.COM_comboBox.Location = new System.Drawing.Point(240, 66);
            this.COM_comboBox.Margin = new System.Windows.Forms.Padding(4);
            this.COM_comboBox.Name = "COM_comboBox";
            this.COM_comboBox.Size = new System.Drawing.Size(191, 51);
            this.COM_comboBox.TabIndex = 0;
            // 
            // connect_button
            // 
            this.connect_button.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.connect_button.Location = new System.Drawing.Point(521, 61);
            this.connect_button.Margin = new System.Windows.Forms.Padding(4);
            this.connect_button.Name = "connect_button";
            this.connect_button.Size = new System.Drawing.Size(164, 68);
            this.connect_button.TabIndex = 4;
            this.connect_button.Text = "連線";
            this.connect_button.UseVisualStyleBackColor = true;
            this.connect_button.Click += new System.EventHandler(this.connect_button_Click);
            // 
            // debug_button
            // 
            this.debug_button.Location = new System.Drawing.Point(964, 76);
            this.debug_button.Margin = new System.Windows.Forms.Padding(4);
            this.debug_button.Name = "debug_button";
            this.debug_button.Size = new System.Drawing.Size(150, 74);
            this.debug_button.TabIndex = 33;
            this.debug_button.Text = "Debug";
            this.debug_button.UseVisualStyleBackColor = true;
            this.debug_button.Click += new System.EventHandler(this.debug_button_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1136, 76);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(482, 74);
            this.textBox1.TabIndex = 40;
            // 
            // Slide_groupBox
            // 
            this.Slide_groupBox.Controls.Add(this.setX_maskedTextBox);
            this.Slide_groupBox.Controls.Add(this.label3);
            this.Slide_groupBox.Controls.Add(this.getX_button);
            this.Slide_groupBox.Controls.Add(this.setX_button);
            this.Slide_groupBox.Controls.Add(this.getX_label);
            this.Slide_groupBox.Controls.Add(this.label4);
            this.Slide_groupBox.Controls.Add(this.label2);
            this.Slide_groupBox.Controls.Add(this.label1);
            this.Slide_groupBox.Controls.Add(this.stop_button);
            this.Slide_groupBox.Controls.Add(this.go_home_button);
            this.Slide_groupBox.Controls.Add(this.search_home_button);
            this.Slide_groupBox.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Slide_groupBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Slide_groupBox.Location = new System.Drawing.Point(13, 214);
            this.Slide_groupBox.Name = "Slide_groupBox";
            this.Slide_groupBox.Size = new System.Drawing.Size(575, 547);
            this.Slide_groupBox.TabIndex = 41;
            this.Slide_groupBox.TabStop = false;
            this.Slide_groupBox.Text = "電動滑軌";
            // 
            // setX_maskedTextBox
            // 
            this.setX_maskedTextBox.Location = new System.Drawing.Point(125, 77);
            this.setX_maskedTextBox.Mask = "###";
            this.setX_maskedTextBox.Name = "setX_maskedTextBox";
            this.setX_maskedTextBox.PromptChar = ' ';
            this.setX_maskedTextBox.Size = new System.Drawing.Size(166, 65);
            this.setX_maskedTextBox.TabIndex = 48;
            this.setX_maskedTextBox.Text = "10";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(14, 197);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 47);
            this.label3.TabIndex = 47;
            this.label3.Text = "當前位置";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // getX_button
            // 
            this.getX_button.Location = new System.Drawing.Point(387, 181);
            this.getX_button.Margin = new System.Windows.Forms.Padding(4);
            this.getX_button.Name = "getX_button";
            this.getX_button.Size = new System.Drawing.Size(163, 74);
            this.getX_button.TabIndex = 46;
            this.getX_button.Text = "讀取";
            this.getX_button.UseVisualStyleBackColor = true;
            this.getX_button.Click += new System.EventHandler(this.getX_button_Click);
            // 
            // setX_button
            // 
            this.setX_button.Location = new System.Drawing.Point(387, 70);
            this.setX_button.Margin = new System.Windows.Forms.Padding(4);
            this.setX_button.Name = "setX_button";
            this.setX_button.Size = new System.Drawing.Size(163, 74);
            this.setX_button.TabIndex = 46;
            this.setX_button.Text = "執行";
            this.setX_button.UseVisualStyleBackColor = true;
            this.setX_button.Click += new System.EventHandler(this.setX_button_Click);
            // 
            // getX_label
            // 
            this.getX_label.AutoSize = true;
            this.getX_label.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.getX_label.ForeColor = System.Drawing.Color.Red;
            this.getX_label.Location = new System.Drawing.Point(196, 197);
            this.getX_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.getX_label.Name = "getX_label";
            this.getX_label.Size = new System.Drawing.Size(91, 47);
            this.getX_label.TabIndex = 45;
            this.getX_label.Text = "N/A";
            this.getX_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(298, 88);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 47);
            this.label2.TabIndex = 45;
            this.label2.Text = "CM";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(24, 88);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 47);
            this.label1.TabIndex = 21;
            this.label1.Text = "位置";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // stop_button
            // 
            this.stop_button.Location = new System.Drawing.Point(133, 451);
            this.stop_button.Margin = new System.Windows.Forms.Padding(4);
            this.stop_button.Name = "stop_button";
            this.stop_button.Size = new System.Drawing.Size(334, 74);
            this.stop_button.TabIndex = 44;
            this.stop_button.Text = "停止";
            this.stop_button.UseVisualStyleBackColor = true;
            this.stop_button.Click += new System.EventHandler(this.stop_button_Click);
            // 
            // go_home_button
            // 
            this.go_home_button.Location = new System.Drawing.Point(133, 369);
            this.go_home_button.Margin = new System.Windows.Forms.Padding(4);
            this.go_home_button.Name = "go_home_button";
            this.go_home_button.Size = new System.Drawing.Size(334, 74);
            this.go_home_button.TabIndex = 43;
            this.go_home_button.Text = "回到原點";
            this.go_home_button.UseVisualStyleBackColor = true;
            this.go_home_button.Click += new System.EventHandler(this.go_home_button_Click);
            // 
            // search_home_button
            // 
            this.search_home_button.Location = new System.Drawing.Point(133, 287);
            this.search_home_button.Margin = new System.Windows.Forms.Padding(4);
            this.search_home_button.Name = "search_home_button";
            this.search_home_button.Size = new System.Drawing.Size(334, 74);
            this.search_home_button.TabIndex = 42;
            this.search_home_button.Text = "尋找原點";
            this.search_home_button.UseVisualStyleBackColor = true;
            this.search_home_button.Click += new System.EventHandler(this.search_home_button_Click);
            // 
            // SetLight_groupBox
            // 
            this.SetLight_groupBox.Controls.Add(A_groupBox);
            this.SetLight_groupBox.Controls.Add(this.All_0_button);
            this.SetLight_groupBox.Controls.Add(groupBox6);
            this.SetLight_groupBox.Controls.Add(groupBox2);
            this.SetLight_groupBox.Controls.Add(groupBox5);
            this.SetLight_groupBox.Controls.Add(groupBox3);
            this.SetLight_groupBox.Controls.Add(groupBox4);
            this.SetLight_groupBox.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SetLight_groupBox.Location = new System.Drawing.Point(622, 214);
            this.SetLight_groupBox.Name = "SetLight_groupBox";
            this.SetLight_groupBox.Size = new System.Drawing.Size(2189, 885);
            this.SetLight_groupBox.TabIndex = 48;
            this.SetLight_groupBox.TabStop = false;
            this.SetLight_groupBox.Text = "燈箱校正";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(298, 197);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 47);
            this.label4.TabIndex = 45;
            this.label4.Text = "CM";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(2823, 1134);
            this.Controls.Add(this.Slide_groupBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.debug_button);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.SetLight_groupBox);
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_FormClosing);
            this.Load += new System.EventHandler(this.main_Load);
            A_groupBox.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox5.ResumeLayout(false);
            groupBox6.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Slide_groupBox.ResumeLayout(false);
            this.Slide_groupBox.PerformLayout();
            this.SetLight_groupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Refresh_button;
        private System.Windows.Forms.ComboBox COM_comboBox;
        private System.Windows.Forms.Button connect_button;
        private System.Windows.Forms.Button debug_button;
        private System.Windows.Forms.Button All_0_button;
        private System.Windows.Forms.Button A150_button;
        private System.Windows.Forms.Button A320_button;
        private System.Windows.Forms.Button A500_button;
        private System.Windows.Forms.Button A50_button;
        private System.Windows.Forms.Button A450_button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.Button AMax_button;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button CWFMax_button;
        private System.Windows.Forms.Button CWF320_button;
        private System.Windows.Forms.Button CWF20_button;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button D65_Max_button;
        private System.Windows.Forms.Button D65_150_button;
        private System.Windows.Forms.Button D65_80_button;
        private System.Windows.Forms.Button D65_20_button;
        private System.Windows.Forms.Button D65_800_button;
        private System.Windows.Forms.Button D65_10_button;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button HZ_Max_button;
        private System.Windows.Forms.Button U30_Max_button;
        private System.Windows.Forms.Button U30_320_button;
        private System.Windows.Forms.Button U30_20_button;
        private System.Windows.Forms.Button TL84_Max_button;
        private System.Windows.Forms.Button TL84_320_button;
        private System.Windows.Forms.Button TL84_20_button;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox Slide_groupBox;
        private System.Windows.Forms.Button setX_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button stop_button;
        private System.Windows.Forms.Button go_home_button;
        private System.Windows.Forms.Button search_home_button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button getX_button;
        private System.Windows.Forms.Label getX_label;
        private System.Windows.Forms.GroupBox SetLight_groupBox;
        private System.Windows.Forms.MaskedTextBox setX_maskedTextBox;
        private System.Windows.Forms.Label label4;
    }
}

