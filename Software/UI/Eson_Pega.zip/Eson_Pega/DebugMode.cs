﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using static Eson_Pega.main;

namespace Eson_Pega
{
    public partial class DebugMode : Form
    {
        #region Private Parameter
        
        private List<string> func = new List<string>()
        {
            "Ping",
            "Set ID",
            "Read Motor Parameter",
            "Write Motor Parameter",
            "Save Data",
            "Get State",
            "Restart",
            "Get IO Status",
            "Set DO",
            "Motor Move",
            "Set Voltage",
            "Read Voltage"
        };

        #endregion

        #region Public Parameter

        #endregion

        #region Class
        RcvSend_Data rcvsend = new RcvSend_Data();  
        #endregion

        #region Thread
        private Thread RefreshingDebugThread;

        #endregion
        public DebugMode()
        {
            InitializeComponent();
            RefreshingDebugThread = new Thread(new ThreadStart(RefreshUI));
            RefreshingDebugThread.Start();
        }

        #region Form Func
        private void Debug_Load(object sender, EventArgs e)
        {
            func_comboBox.DataSource = func;            
        }

        private void Debug_FormClosing(object sender, FormClosingEventArgs e)
        {
            RefreshingDebugThread.Abort();
        }
        #endregion

        #region RefreshUI Func
        private void RefreshUI()
        {
            while (true)//CommonSerial.OutputPort.IsOpen) 
            {                
                if (!string.IsNullOrEmpty(RcvSend_Data.debugReceive_String))
                {
                    receive_textBox.AppendText(RcvSend_Data.debugReceive_String);
                    RcvSend_Data.debugReceive_String = string.Empty;
                }

                if (!string.IsNullOrEmpty(RcvSend_Data.debugSend_String))
                {
                    send_textBox.AppendText(RcvSend_Data.debugSend_String);
                    RcvSend_Data.debugSend_String = string.Empty;
                }

                Refresh_Param();

                Thread.Sleep(10);
            }
        }

        private void Disable_Label_TextBox(Label lb, TextBox tb)
        {
            lb.Visible = false;
            tb.Visible = false;
        }

        private void Enable_Label_TextBox(Label lb, TextBox tb)
        {   
            lb.Visible = true;
            tb.Visible = true;
        }

        private void Refresh_Param()
        {
            if (func_comboBox.Text.ToString() == "Ping")
            {
                Disable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Set ID")
            {
                param1_label.Text = "Set HMI ID";
                Enable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Read Motor Parameter")
            {
                param1_label.Text = "Motor Axis";
                Enable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Write Motor Parameter")
            {
                param1_label.Text = "Motor Axis";
                param2_label.Text = "Frequency";
                param3_label.Text = "Acceleration";
                Enable_Label_TextBox(param1_label, param1_textBox);
                Enable_Label_TextBox(param2_label, param2_textBox);
                Enable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Save Data")
            {
                Disable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Get State")
            {
                Disable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Restart")
            {
                Disable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Get IO Status")
            {
                param1_label.Text = "IO Pin";
                Enable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Set DO")
            {
                Disable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Motor Move")
            {
                param1_label.Text = "Motor Axis";
                param2_label.Text = "Steps";
                Enable_Label_TextBox(param1_label, param1_textBox);
                Enable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Set Voltage")
            {
                param1_label.Text = "Set Percent";
                Enable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if (func_comboBox.Text == "Read Voltage")
            {
                Disable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
            else if(func_comboBox.Text.Contains("F1"))
            {
                Disable_Label_TextBox(hmiid_label, hmiid_textBox);
                Disable_Label_TextBox(param1_label, param1_textBox);
                Disable_Label_TextBox(param2_label, param2_textBox);
                Disable_Label_TextBox(param3_label, param3_textBox);
            }
        }
        #endregion


        #region Button Func

        private void Send_button_Click(object sender, EventArgs e)
        {
            byte hmiid;
            if (!string.IsNullOrEmpty(hmiid_textBox.Text))
                hmiid = byte.Parse(hmiid_textBox.Text);
            else
                hmiid = 0;

            if (func_comboBox.Text == "Ping")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.PING);
            }
            else if (func_comboBox.Text == "Set ID")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.SETID, setid: byte.Parse(param1_textBox.Text));
            }
            else if (func_comboBox.Text == "Read Motor Parameter")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.READ_MOTOR_PARA, motor_axis: byte.Parse(param1_textBox.Text));

            }
            else if (func_comboBox.Text == "Write Motor Parameter")
            {
                rcvsend.SendData
                (
                    CommonSerial.OutputPort,
                    hmiid,
                    RcvSend_Data.WRITE_MOTOR_PAPA,
                    motor_axis: byte.Parse(param1_textBox.Text),
                    freq: byte.Parse(param2_textBox.Text),
                    acc: byte.Parse(param3_textBox.Text)
                );

            }
            else if (func_comboBox.Text == "Save Data")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.SAVE_DATA);
            }
            else if (func_comboBox.Text == "Get State") 
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.STATE);
            }
            else if (func_comboBox.Text == "Restart")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.RESTART);

            }
            else if (func_comboBox.Text == "Get IO Status")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.IO_STATUS, io: byte.Parse(param1_textBox.Text));

            }
            else if (func_comboBox.Text == "Set DO")
            {

            }
            else if (func_comboBox.Text == "Motor Move")
            {
                rcvsend.SendData
                (
                    CommonSerial.OutputPort,
                    hmiid,
                    RcvSend_Data.MOTOR_MOVE,
                    motor_axis: byte.Parse(param1_textBox.Text),
                    steps: byte.Parse(param2_textBox.Text)
                );
            }
            else if (func_comboBox.Text == "Set Voltage")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.SET_VOLT, setVolt_per: int.Parse(param1_textBox.Text));

            }
            else if (func_comboBox.Text == "Read Voltage")
            {
                rcvsend.SendData(CommonSerial.OutputPort, hmiid, RcvSend_Data.READ_VOLT);
            }
            else if (func_comboBox.Text.Contains("F1"))
            {
                byte[] msg = HexStringToByteArray(func_comboBox.Text);
                rcvsend.SerialSend(CommonSerial.OutputPort, msg, msg.Length);
                RcvSend_Data.debugSend_String += "Send: " + BitConverter.ToString(msg) + "\r\n";
            }
        }

        #endregion
        public byte[] HexStringToByteArray(string s)
        {
            s = s.Replace(" ", "");
            byte[] buffer = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
            {
                buffer[i / 2] = (byte)Convert.ToByte(s.Substring(i, 2), 16);
            }

            return buffer;
        }
            
        private void PingTest_button_Click(object sender, EventArgs e)
        {
            rcvsend.SendData(CommonSerial.OutputPort, 1, RcvSend_Data.PING);
            Thread.Sleep(100);
            rcvsend.SendData(CommonSerial.OutputPort, 2, RcvSend_Data.PING);
            Thread.Sleep(100);
            rcvsend.SendData(CommonSerial.OutputPort, 3, RcvSend_Data.PING);
            Thread.Sleep(100);
            rcvsend.SendData(CommonSerial.OutputPort, 4, RcvSend_Data.PING);
        }



        private void ClearSendTB_button_Click(object sender, EventArgs e)
        {
            send_textBox.Clear();
        }

        private void ClearRcvTB_button_Click(object sender, EventArgs e)
        {
            receive_textBox.Clear();
        }

        private void pingAll_button_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(delegate ()
            {
                //rcvsend.setCWF();
            });
            thread.Start();
        }
    }
}
