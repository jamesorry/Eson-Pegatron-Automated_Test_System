﻿
namespace Eson_Pega
{
    partial class LightTube
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.LightPerMinus2_button = new System.Windows.Forms.Button();
            this.light_lux_label = new System.Windows.Forms.Label();
            this.LightPerMinus1_button = new System.Windows.Forms.Button();
            this.LightPerPlus2_button = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.LightPerPlus1_button = new System.Windows.Forms.Button();
            this.LightPer2_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.LightPer1_textBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(889, 446);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(152, 54);
            this.label15.TabIndex = 39;
            this.label15.Text = "RIGHT";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(254, 452);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 54);
            this.label14.TabIndex = 38;
            this.label14.Text = "LEFT";
            // 
            // LightPerMinus2_button
            // 
            this.LightPerMinus2_button.Font = new System.Drawing.Font("新細明體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LightPerMinus2_button.Location = new System.Drawing.Point(898, 328);
            this.LightPerMinus2_button.Name = "LightPerMinus2_button";
            this.LightPerMinus2_button.Size = new System.Drawing.Size(70, 69);
            this.LightPerMinus2_button.TabIndex = 37;
            this.LightPerMinus2_button.Text = "▼";
            this.LightPerMinus2_button.UseVisualStyleBackColor = true;
            this.LightPerMinus2_button.Click += new System.EventHandler(this.LightPerMinus2_button_Click);
            // 
            // light_lux_label
            // 
            this.light_lux_label.AutoSize = true;
            this.light_lux_label.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.light_lux_label.Location = new System.Drawing.Point(80, 48);
            this.light_lux_label.Name = "light_lux_label";
            this.light_lux_label.Size = new System.Drawing.Size(318, 81);
            this.light_lux_label.TabIndex = 34;
            this.light_lux_label.Text = "Light_Lux";
            // 
            // LightPerMinus1_button
            // 
            this.LightPerMinus1_button.Font = new System.Drawing.Font("新細明體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LightPerMinus1_button.Location = new System.Drawing.Point(263, 337);
            this.LightPerMinus1_button.Name = "LightPerMinus1_button";
            this.LightPerMinus1_button.Size = new System.Drawing.Size(70, 69);
            this.LightPerMinus1_button.TabIndex = 36;
            this.LightPerMinus1_button.Text = "▼";
            this.LightPerMinus1_button.UseVisualStyleBackColor = true;
            this.LightPerMinus1_button.Click += new System.EventHandler(this.LightPerMinus1_button_Click);
            // 
            // LightPerPlus2_button
            // 
            this.LightPerPlus2_button.Font = new System.Drawing.Font("新細明體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LightPerPlus2_button.Location = new System.Drawing.Point(822, 328);
            this.LightPerPlus2_button.Name = "LightPerPlus2_button";
            this.LightPerPlus2_button.Size = new System.Drawing.Size(70, 69);
            this.LightPerPlus2_button.TabIndex = 33;
            this.LightPerPlus2_button.Text = "▲";
            this.LightPerPlus2_button.UseVisualStyleBackColor = true;
            this.LightPerPlus2_button.Click += new System.EventHandler(this.LightPerPlus2_button_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(185, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 129);
            this.label3.TabIndex = 20;
            this.label3.Text = "💡";
            // 
            // LightPerPlus1_button
            // 
            this.LightPerPlus1_button.Font = new System.Drawing.Font("新細明體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LightPerPlus1_button.Location = new System.Drawing.Point(187, 337);
            this.LightPerPlus1_button.Name = "LightPerPlus1_button";
            this.LightPerPlus1_button.Size = new System.Drawing.Size(70, 69);
            this.LightPerPlus1_button.TabIndex = 32;
            this.LightPerPlus1_button.Text = "▲";
            this.LightPerPlus1_button.UseVisualStyleBackColor = true;
            this.LightPerPlus1_button.Click += new System.EventHandler(this.LightPerPlus1_button_Click);
            // 
            // LightPer2_textBox
            // 
            this.LightPer2_textBox.Font = new System.Drawing.Font("新細明體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LightPer2_textBox.Location = new System.Drawing.Point(713, 329);
            this.LightPer2_textBox.Name = "LightPer2_textBox";
            this.LightPer2_textBox.Size = new System.Drawing.Size(100, 59);
            this.LightPer2_textBox.TabIndex = 35;
            this.LightPer2_textBox.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(680, 151);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(153, 129);
            this.label13.TabIndex = 25;
            this.label13.Text = "💡";
            // 
            // LightPer1_textBox
            // 
            this.LightPer1_textBox.Font = new System.Drawing.Font("新細明體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LightPer1_textBox.Location = new System.Drawing.Point(78, 338);
            this.LightPer1_textBox.Name = "LightPer1_textBox";
            this.LightPer1_textBox.Size = new System.Drawing.Size(100, 59);
            this.LightPer1_textBox.TabIndex = 31;
            this.LightPer1_textBox.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(812, 151);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(153, 129);
            this.label12.TabIndex = 26;
            this.label12.Text = "💡";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(446, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(153, 129);
            this.label4.TabIndex = 22;
            this.label4.Text = "💡";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(883, 476);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 24);
            this.label1.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(946, 151);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(153, 129);
            this.label11.TabIndex = 27;
            this.label11.Text = "💡";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(314, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 129);
            this.label5.TabIndex = 21;
            this.label5.Text = "💡";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(53, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 129);
            this.label2.TabIndex = 19;
            this.label2.Text = "💡";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(1078, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 129);
            this.label10.TabIndex = 28;
            this.label10.Text = "💡";
            // 
            // LightTube
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.LightPerMinus2_button);
            this.Controls.Add(this.light_lux_label);
            this.Controls.Add(this.LightPerMinus1_button);
            this.Controls.Add(this.LightPerPlus2_button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LightPerPlus1_button);
            this.Controls.Add(this.LightPer2_textBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.LightPer1_textBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label10);
            this.Name = "LightTube";
            this.Size = new System.Drawing.Size(1266, 571);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button LightPerMinus2_button;
        private System.Windows.Forms.Label light_lux_label;
        private System.Windows.Forms.Button LightPerMinus1_button;
        private System.Windows.Forms.Button LightPerPlus2_button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button LightPerPlus1_button;
        private System.Windows.Forms.TextBox LightPer2_textBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox LightPer1_textBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
    }
}
