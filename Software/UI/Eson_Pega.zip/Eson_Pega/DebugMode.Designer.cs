﻿
namespace Eson_Pega
{
    partial class DebugMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.send_textBox = new System.Windows.Forms.TextBox();
            this.func_comboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Send_button = new System.Windows.Forms.Button();
            this.parameter_groupBox = new System.Windows.Forms.GroupBox();
            this.param3_textBox = new System.Windows.Forms.TextBox();
            this.param3_label = new System.Windows.Forms.Label();
            this.param2_textBox = new System.Windows.Forms.TextBox();
            this.param2_label = new System.Windows.Forms.Label();
            this.param1_textBox = new System.Windows.Forms.TextBox();
            this.hmiid_textBox = new System.Windows.Forms.TextBox();
            this.param1_label = new System.Windows.Forms.Label();
            this.hmiid_label = new System.Windows.Forms.Label();
            this.receive_textBox = new System.Windows.Forms.TextBox();
            this.PingTest_button = new System.Windows.Forms.Button();
            this.ClearSendTB_button = new System.Windows.Forms.Button();
            this.ClearRcvTB_button = new System.Windows.Forms.Button();
            this.pingAll_button = new System.Windows.Forms.Button();
            this.parameter_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // send_textBox
            // 
            this.send_textBox.Location = new System.Drawing.Point(874, 13);
            this.send_textBox.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.send_textBox.Multiline = true;
            this.send_textBox.Name = "send_textBox";
            this.send_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.send_textBox.Size = new System.Drawing.Size(979, 586);
            this.send_textBox.TabIndex = 23;
            // 
            // func_comboBox
            // 
            this.func_comboBox.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.func_comboBox.FormattingEnabled = true;
            this.func_comboBox.Location = new System.Drawing.Point(199, 38);
            this.func_comboBox.Name = "func_comboBox";
            this.func_comboBox.Size = new System.Drawing.Size(516, 48);
            this.func_comboBox.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(30, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 40);
            this.label1.TabIndex = 25;
            this.label1.Text = "Fucntion";
            // 
            // Send_button
            // 
            this.Send_button.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Send_button.Location = new System.Drawing.Point(730, 38);
            this.Send_button.Name = "Send_button";
            this.Send_button.Size = new System.Drawing.Size(119, 48);
            this.Send_button.TabIndex = 26;
            this.Send_button.Text = "Send";
            this.Send_button.UseVisualStyleBackColor = true;
            this.Send_button.Click += new System.EventHandler(this.Send_button_Click);
            // 
            // parameter_groupBox
            // 
            this.parameter_groupBox.Controls.Add(this.param3_textBox);
            this.parameter_groupBox.Controls.Add(this.param3_label);
            this.parameter_groupBox.Controls.Add(this.param2_textBox);
            this.parameter_groupBox.Controls.Add(this.param2_label);
            this.parameter_groupBox.Controls.Add(this.param1_textBox);
            this.parameter_groupBox.Controls.Add(this.hmiid_textBox);
            this.parameter_groupBox.Controls.Add(this.param1_label);
            this.parameter_groupBox.Controls.Add(this.hmiid_label);
            this.parameter_groupBox.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.parameter_groupBox.Location = new System.Drawing.Point(37, 110);
            this.parameter_groupBox.Name = "parameter_groupBox";
            this.parameter_groupBox.Size = new System.Drawing.Size(812, 401);
            this.parameter_groupBox.TabIndex = 27;
            this.parameter_groupBox.TabStop = false;
            this.parameter_groupBox.Text = "參數設定";
            // 
            // param3_textBox
            // 
            this.param3_textBox.Location = new System.Drawing.Point(345, 303);
            this.param3_textBox.Name = "param3_textBox";
            this.param3_textBox.Size = new System.Drawing.Size(165, 50);
            this.param3_textBox.TabIndex = 35;
            // 
            // param3_label
            // 
            this.param3_label.AutoSize = true;
            this.param3_label.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.param3_label.Location = new System.Drawing.Point(114, 313);
            this.param3_label.Name = "param3_label";
            this.param3_label.Size = new System.Drawing.Size(133, 40);
            this.param3_label.TabIndex = 34;
            this.param3_label.Text = "Param1";
            // 
            // param2_textBox
            // 
            this.param2_textBox.Location = new System.Drawing.Point(345, 223);
            this.param2_textBox.Name = "param2_textBox";
            this.param2_textBox.Size = new System.Drawing.Size(165, 50);
            this.param2_textBox.TabIndex = 33;
            // 
            // param2_label
            // 
            this.param2_label.AutoSize = true;
            this.param2_label.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.param2_label.Location = new System.Drawing.Point(114, 233);
            this.param2_label.Name = "param2_label";
            this.param2_label.Size = new System.Drawing.Size(133, 40);
            this.param2_label.TabIndex = 32;
            this.param2_label.Text = "Param2";
            // 
            // param1_textBox
            // 
            this.param1_textBox.Location = new System.Drawing.Point(345, 148);
            this.param1_textBox.Name = "param1_textBox";
            this.param1_textBox.Size = new System.Drawing.Size(165, 50);
            this.param1_textBox.TabIndex = 31;
            // 
            // hmiid_textBox
            // 
            this.hmiid_textBox.Location = new System.Drawing.Point(345, 70);
            this.hmiid_textBox.Name = "hmiid_textBox";
            this.hmiid_textBox.Size = new System.Drawing.Size(165, 50);
            this.hmiid_textBox.TabIndex = 30;
            // 
            // param1_label
            // 
            this.param1_label.AutoSize = true;
            this.param1_label.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.param1_label.Location = new System.Drawing.Point(114, 158);
            this.param1_label.Name = "param1_label";
            this.param1_label.Size = new System.Drawing.Size(133, 40);
            this.param1_label.TabIndex = 29;
            this.param1_label.Text = "Param1";
            // 
            // hmiid_label
            // 
            this.hmiid_label.AutoSize = true;
            this.hmiid_label.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.hmiid_label.Location = new System.Drawing.Point(114, 73);
            this.hmiid_label.Name = "hmiid_label";
            this.hmiid_label.Size = new System.Drawing.Size(122, 40);
            this.hmiid_label.TabIndex = 28;
            this.hmiid_label.Text = "HMI ID";
            // 
            // receive_textBox
            // 
            this.receive_textBox.Location = new System.Drawing.Point(11, 607);
            this.receive_textBox.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.receive_textBox.Multiline = true;
            this.receive_textBox.Name = "receive_textBox";
            this.receive_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.receive_textBox.Size = new System.Drawing.Size(1842, 586);
            this.receive_textBox.TabIndex = 28;
            // 
            // PingTest_button
            // 
            this.PingTest_button.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.PingTest_button.Location = new System.Drawing.Point(37, 527);
            this.PingTest_button.Name = "PingTest_button";
            this.PingTest_button.Size = new System.Drawing.Size(162, 72);
            this.PingTest_button.TabIndex = 29;
            this.PingTest_button.Text = "Ping1_4";
            this.PingTest_button.UseVisualStyleBackColor = true;
            this.PingTest_button.Click += new System.EventHandler(this.PingTest_button_Click);
            // 
            // ClearSendTB_button
            // 
            this.ClearSendTB_button.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ClearSendTB_button.Location = new System.Drawing.Point(1712, 516);
            this.ClearSendTB_button.Name = "ClearSendTB_button";
            this.ClearSendTB_button.Size = new System.Drawing.Size(141, 83);
            this.ClearSendTB_button.TabIndex = 30;
            this.ClearSendTB_button.Text = "Clear";
            this.ClearSendTB_button.UseVisualStyleBackColor = true;
            this.ClearSendTB_button.Click += new System.EventHandler(this.ClearSendTB_button_Click);
            // 
            // ClearRcvTB_button
            // 
            this.ClearRcvTB_button.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ClearRcvTB_button.Location = new System.Drawing.Point(1712, 1110);
            this.ClearRcvTB_button.Name = "ClearRcvTB_button";
            this.ClearRcvTB_button.Size = new System.Drawing.Size(141, 83);
            this.ClearRcvTB_button.TabIndex = 31;
            this.ClearRcvTB_button.Text = "Clear";
            this.ClearRcvTB_button.UseVisualStyleBackColor = true;
            this.ClearRcvTB_button.Click += new System.EventHandler(this.ClearRcvTB_button_Click);
            // 
            // pingAll_button
            // 
            this.pingAll_button.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.pingAll_button.Location = new System.Drawing.Point(230, 527);
            this.pingAll_button.Name = "pingAll_button";
            this.pingAll_button.Size = new System.Drawing.Size(162, 72);
            this.pingAll_button.TabIndex = 32;
            this.pingAll_button.Text = "Ping All";
            this.pingAll_button.UseVisualStyleBackColor = true;
            this.pingAll_button.Click += new System.EventHandler(this.pingAll_button_Click);
            // 
            // Debug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1864, 1243);
            this.Controls.Add(this.pingAll_button);
            this.Controls.Add(this.ClearRcvTB_button);
            this.Controls.Add(this.ClearSendTB_button);
            this.Controls.Add(this.PingTest_button);
            this.Controls.Add(this.receive_textBox);
            this.Controls.Add(this.parameter_groupBox);
            this.Controls.Add(this.Send_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.func_comboBox);
            this.Controls.Add(this.send_textBox);
            this.Name = "Debug";
            this.Text = "Debug";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Debug_FormClosing);
            this.Load += new System.EventHandler(this.Debug_Load);
            this.parameter_groupBox.ResumeLayout(false);
            this.parameter_groupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox send_textBox;
        private System.Windows.Forms.ComboBox func_comboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Send_button;
        private System.Windows.Forms.GroupBox parameter_groupBox;
        private System.Windows.Forms.TextBox hmiid_textBox;
        private System.Windows.Forms.Label param1_label;
        private System.Windows.Forms.Label hmiid_label;
        private System.Windows.Forms.TextBox param3_textBox;
        private System.Windows.Forms.Label param3_label;
        private System.Windows.Forms.TextBox param2_textBox;
        private System.Windows.Forms.Label param2_label;
        private System.Windows.Forms.TextBox param1_textBox;
        private System.Windows.Forms.TextBox receive_textBox;
        private System.Windows.Forms.Button PingTest_button;
        private System.Windows.Forms.Button ClearSendTB_button;
        private System.Windows.Forms.Button ClearRcvTB_button;
        private System.Windows.Forms.Button pingAll_button;
    }
}