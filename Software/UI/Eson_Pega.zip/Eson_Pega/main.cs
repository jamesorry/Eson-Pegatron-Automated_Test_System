﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Diagnostics;
/******************待修正******************/

namespace Eson_Pega
{
    public partial class main : Form
    {
        #region Private Parameter
        public static bool isReceiving;
        #endregion

        #region Public Parameter
        
        #endregion

        #region Class
        public RcvSend_Data rcvsend = new RcvSend_Data();
        public SerialPort InputPort = new SerialPort("COM11", 115200, Parity.None);
        public static class CommonSerial
        {
            public static SerialPort OutputPort = new SerialPort();
        }

        #endregion

        #region Thread
        //Thread RefreshingUIThread;
        #endregion
        public main()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
            //RefreshingUIThread = new Thread(new ThreadStart(RefreshUI));
            //RefreshingUIThread.Start();
        }


        #region Form Func
        private void main_Load(object sender, EventArgs e)
        {
            GetComPort(); 
            InputPort.Open();
            InputPort.DataReceived += new SerialDataReceivedEventHandler(InputPort_DataReceived);
        }

        private void main_FormClosing(object sender, FormClosingEventArgs e)
        {
            //RefreshingUIThread.Abort();
            InputPort.Close();
            InputPort.DataReceived -= new SerialDataReceivedEventHandler(InputPort_DataReceived);
            CommonSerial.OutputPort.Close();
            CommonSerial.OutputPort.DataReceived -= new SerialDataReceivedEventHandler(OutputPort_DataReceived);
            
        }
        #endregion


        #region Button Func
        private void connect_button_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            if (COM_comboBox.Text == "LH032716576")
            {
                COM_comboBox.Text = string.Empty;
                foreach(Form OpenForm in System.Windows.Forms.Application.OpenForms)
                {
                    //Debug.WriteLine(OpenForm.GetType().FullName);
                    if (OpenForm.GetType().FullName == "Eson_Pega.DebugMode")
                    {
                        isOpen = true;
                        break;
                    }
                    else
                        isOpen = false;
                }
                if (!isOpen)
                {
                    DebugMode debug = new DebugMode();
                    debug.Show();
                }
            }

            else
            {
                if (CommonSerial.OutputPort.IsOpen)
                {
                    try
                    {
                        CommonSerial.OutputPort.Close();
                        connect_button.BackColor = Control.DefaultBackColor;
                        connect_button.Text = "連線";
                        CommonSerial.OutputPort.DataReceived -= new SerialDataReceivedEventHandler(OutputPort_DataReceived);
                        rcvsend.present_state = 0x03;
                        return;
                    }
                    catch (Exception disconn)
                    {
                        MessageBox.Show(disconn.ToString());
                    }
                }
                if (!string.IsNullOrEmpty(COM_comboBox.Text) && !CommonSerial.OutputPort.IsOpen)
                {
                    try
                    {
                        //ComCommonPort設定
                        CommonSerial.OutputPort.PortName = COM_comboBox.Text;
                        CommonSerial.OutputPort.BaudRate = 38400;// 115200;
                        CommonSerial.OutputPort.StopBits = StopBits.One;
                        CommonSerial.OutputPort.Parity = Parity.None;
                        CommonSerial.OutputPort.ReadTimeout = 300;
                        CommonSerial.OutputPort.Handshake = Handshake.None;

                        CommonSerial.OutputPort.Open();
                        CommonSerial.OutputPort.DataReceived += new SerialDataReceivedEventHandler(OutputPort_DataReceived);

                        ////Ping
                        ////Thread.Sleep(1000);
                        //int i = 100;
                        //rcvsend.SendData(CommonSerial.CommonPort, 0x00, RcvSend_Data.PING);
                        //while (rcvsend.ping == false)
                        //{
                        //    if (i > 0)
                        //    {
                        //        i--;
                        //        Thread.Sleep(1);
                        //    }
                        //    else
                        //    {
                        //        rcvsend.ping = false;
                        //        MessageBox.Show("未正確連接HMI");
                        //        break;
                        //    }
                        //}

                        //if (rcvsend.ping == true)
                        //{
                        connect_button.BackColor = Color.LightGreen;
                        connect_button.Text = "斷線";
                        //rcvsend.ping = false;
                        //}

                        //else
                        //{
                        //    CommonSerial.CommonPort.Close();
                        //    rcvsend.ping = false;
                        //    CommonSerial.CommonPort.DataReceived -= new SerialDataReceivedEventHandler(CommonPort_DataReceived);
                        //}

                    }
                    catch (Exception conn)
                    {
                        MessageBox.Show(conn.ToString());
                    }
                }
            }
        }

        private void Refresh_button_Click(object sender, EventArgs e)
        {
            GetComPort();
        }

        private void setX_button_Click(object sender, EventArgs e)
        {
            rcvsend.setX(int.Parse(setX_maskedTextBox.Text));
        }

        private void getX_button_Click(object sender, EventArgs e)
        {
            getX_label.Text = Convert.ToInt32(rcvsend.getX()).ToString();
        }

        private void search_home_button_Click(object sender, EventArgs e)
        {
            rcvsend.searchHome();
        }

        private void go_home_button_Click(object sender, EventArgs e)
        {
            rcvsend.gohome();
        }

        private void stop_button_Click(object sender, EventArgs e)
        {
            rcvsend.stop();
        }

        #region A Btn
        private void A50_button_Click(object sender, EventArgs e)
        {
            SettingPage_Init("A 50Lux");
        }

        private void A150_button_Click(object sender, EventArgs e)
        {

        }

        private void A320_button_Click(object sender, EventArgs e)
        {

        }

        private void A450_button5_Click(object sender, EventArgs e)
        {

        }

        private void A500_button_Click(object sender, EventArgs e)
        {

        }

        private void AMax_button_Click(object sender, EventArgs e)
        {

        }

        #endregion

        #region CWF Btn
        private void CWF20_button_Click(object sender, EventArgs e)
            {
                SettingPage_Init("CWF 20Lux");
            }

        private void CWF320_button_Click(object sender, EventArgs e)
        {

        }

        private void CWFMax_button_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region D65 Btn
        private void D65_10_button_Click(object sender, EventArgs e)
        {

        }
        private void D65_20_button_Click(object sender, EventArgs e)
        {

        }

        private void D65_80_button_Click(object sender, EventArgs e)
        {

        }

        private void D65_150_button_Click(object sender, EventArgs e)
        {

        }

        private void D65_800_button_Click(object sender, EventArgs e)
        {

        }

        private void D65_Max_button_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region HZ Btn
        private void HZ_Max_button_Click(object sender, EventArgs e)
        {
            SettingPage_Init("HZ 1000Lux");
        }
       #endregion

        #region TL84 Btn
        private void TL84_20_button_Click(object sender, EventArgs e)
        {

        }   
        private void TL84_320_button_Click(object sender, EventArgs e)
        {

        }
        private void TL84_Max_button_Click(object sender, EventArgs e)
        {

        }

        #endregion

        #region U30 Btn
        private void U30_20_button_Click(object sender, EventArgs e)
        {

        }

        private void U30_320_button_Click(object sender, EventArgs e)
        {

        }

        private void U30_Max_button_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #endregion


        #region Serial Func
        protected override void WndProc(ref Message m)
        {
            const int WM_DEVICECHANGE = 0x219; //設備改變
            const int DBT_DEVICEARRIVAL = 0x8000; //檢測到新設備
            const int DBT_DEVICEREMOVECOMPLETE = 0x8004; //移除設備
            //const int DBT_DEVTYP_CommonPort = 0x00000003;
            base.WndProc(ref m);//調用父類方法，以確保其他功能正常
            switch (m.Msg)
            {
                case WM_DEVICECHANGE://設備改變事件
                    switch ((int)m.WParam)
                    {
                        case DBT_DEVICEARRIVAL:
                            //int dbccSize = Marshal.ReadInt32(m.LParam, 0);
                            //int devType = Marshal.ReadInt32(m.LParam, 4);                            
                            break;

                        case DBT_DEVICEREMOVECOMPLETE:
                            if (!CommonSerial.OutputPort.IsOpen)
                            {
                                CommonSerial.OutputPort.Close();
                                CommonSerial.OutputPort.DataReceived -= new SerialDataReceivedEventHandler(OutputPort_DataReceived);
                                connect_button.BackColor = Control.DefaultBackColor;
                                connect_button.Text = "連線";
                            }
                            break;
                    }
                    //刷新串口設備
                    GetComPort();
                    break;
            }
        }
        private void GetComPort()
        {
            string[] names = SerialPort.GetPortNames();
            COM_comboBox.Items.Clear();
            COM_comboBox.Text = string.Empty;
            foreach (string s in names)
            {
                COM_comboBox.Items.Add(s);
            }

            if (names.Length > 0)
            {
                COM_comboBox.SelectedIndex = 0;
            }
        }

        private void OutputPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            isReceiving = true;
            Thread.Sleep(10);  //（毫秒）等待一定時間，確保資料的完整性 int len      
            if (CommonSerial.OutputPort.IsOpen)
            {
                int len = CommonSerial.OutputPort.BytesToRead;
                if (len != 0)
                {
                    byte[] buff = new byte[len];
                    CommonSerial.OutputPort.Read(buff, 0, len);

                    for(int i = 0; i < 256; i++)
                    {
                        if (rcvsend.rcvbuff[i] == 0)
                        {
                            buff.CopyTo(rcvsend.rcvbuff, i);
                            //rcvsend.PrintRcvDebugString(BitConverter.ToString(buff));
                            //rcvsend.PrintRcvDebugString(BitConverter.ToString(rcvsend.rcvbuff));
                            break;
                        }
                        else
                        {
                            rcvsend.PrintRcvDebugString("Error num: " + i.ToString());
                            rcvsend.PrintRcvDebugString("Receive: " + BitConverter.ToString(buff));
                            rcvsend.PrintRcvDebugString("Rcvbuff: " + BitConverter.ToString(rcvsend.rcvbuff));
                            rcvsend.PrintRcvDebugString("rcvbuff Error");
                            break;
                        }
                    }
                    //buff.CopyTo(rcvsend.rcvbuff, 0);
                    //RcvSend_Data.debugReceive_String += BitConverter.ToString(rcvsend.rcvbuff);
                    rcvsend.GetCmd();


                    //RcvSend_Data.debugReceive_String += "RAW: " + BitConverter.ToString(buff) + "\r\n";
                }
            }
            isReceiving = false;
        }


        private void InputPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            
            Thread.Sleep(10);  //（毫秒）等待一定時間，確保資料的完整性 int len      
            if (InputPort.IsOpen)
            {
                int len = InputPort.BytesToRead;
                if (len != 0)
                {
                    byte[] buff = new byte[len];
                    InputPort.Read(buff, 0, len);

                    string rcvString = Encoding.ASCII.GetString(buff);

                    if (rcvString.Contains("\r\n"))
                        rcvString = rcvString.Remove(rcvString.IndexOf("\r\n"));
                    else
                        return;

                    textBox1.AppendText(rcvString + "\r\n");
                    if (!string.IsNullOrEmpty(rcvString))
                    {
                        if (rcvsend.Command_Task(rcvString))
                        {
                            textBox1.AppendText("Done");
                            rcvString = string.Empty;
                        }
                        //textBox1.AppendText(BitConverter.ToString(rcvsend.Command_Task(rcvString)) + "\r\n");
                        else
                            textBox1.AppendText("NULL\r\n");
                    }
                    else
                    {
                        rcvString.Trim();
                    }
                }
            }
        }

        #endregion


        #region Other Func
        private void RefreshUI()
        {
            while (true)
            {
                //RefreshInputPort();
                Thread.Sleep(50);            
            }
        }
        
        private void RefreshInputPort()
        {
            if (InputPort.IsOpen)
            {
                InputPort.Open();
                InputPort.DataReceived += new SerialDataReceivedEventHandler(InputPort_DataReceived);
            }

            else
            {
                InputPort.Close();
                InputPort.DataReceived -= new SerialDataReceivedEventHandler(InputPort_DataReceived);
            }
            Thread.Sleep(200);           
        }



        #endregion

        private void debug_button_Click(object sender, EventArgs e)
        {
            DebugMode debug = new DebugMode();
            debug.Show();
        }

        private void SettingPage_Init(string light)
        {
            SetLight sl = new SetLight(light);
            sl.Show();
        }

    }
}
