﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eson_Pega
{
    public partial class LightTube : UserControl
    {
        public LightTube(string light)
        {
            InitializeComponent();
            light_lux_label.Text = light;
        }


        #region Button Func

        private void LightPerPlus1_button_Click(object sender, EventArgs e)
        {
            LightPer1_textBox.Text = (int.Parse(LightPer1_textBox.Text) + 1).ToString();
        }

        private void LightPerMinus1_button_Click(object sender, EventArgs e)
        {
            LightPer1_textBox.Text = (int.Parse(LightPer1_textBox.Text) - 1).ToString();
        }

        private void LightPerPlus2_button_Click(object sender, EventArgs e)
        {
            LightPer2_textBox.Text = (int.Parse(LightPer2_textBox.Text) + 1).ToString();
        }

        private void LightPerMinus2_button_Click(object sender, EventArgs e)
        {
            LightPer2_textBox.Text = (int.Parse(LightPer2_textBox.Text) - 1).ToString();
        }

        #endregion
    }
}
