﻿
namespace Eson_Pega
{
    partial class SetLight
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LightSwitch_panel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // LightSwitch_panel
            // 
            this.LightSwitch_panel.Location = new System.Drawing.Point(12, 12);
            this.LightSwitch_panel.Name = "LightSwitch_panel";
            this.LightSwitch_panel.Size = new System.Drawing.Size(1646, 1014);
            this.LightSwitch_panel.TabIndex = 0;
            // 
            // SetLight
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1670, 1038);
            this.Controls.Add(this.LightSwitch_panel);
            this.Name = "SetLight";
            this.Text = "SetLight";
            this.Load += new System.EventHandler(this.SetLight_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel LightSwitch_panel;
    }
}