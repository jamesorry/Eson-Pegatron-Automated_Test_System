﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO.Ports;
using System.Collections;
using System.Diagnostics;
using static Eson_Pega.main;


namespace Eson_Pega
{
    public class RcvSend_Data
    {
        #region Private Parameter
        private byte[] sendData = new byte[128];
        private byte[] AckCheck = new byte[20];

        ///////////////HMI ID///////////////
        private const int XYZ_MOTOR = 1;
        //AXIS
        private const int X_AXIS = 1;
        private const int Y_AXIS = 1;
        private const int Z_AXIS = 1;

        //左控制卡
        private const int LEFT_CONTROL = 1;
        //AXIS
        private const int LEFT_ROTATE = 1;
        private const int LEFT_A_VR = 1;
        private const int LEFT_HZ_VR = 1;

        //右控制卡
        private const int RIGHT_CONTROL = 1;
        //AXIS
        private const int RIGHT_ROTATE = 1;
        private const int RIGHT_A_VR = 1;
        private const int RIGHT_HZ_VR = 1;

        //燈管
        private const int CWF_1 = 1;
        private const int CWF_2 = 2;
        private const int CWF_3 = 3;
        private const int CWF_4 = 4;

        private const int D65_1 = 5;
        private const int D65_2 = 6;
        private const int D65_3 = 7;
        private const int D65_4 = 8;

        private const int TL84_1 = 1;
        private const int TL84_2 = 1;
        private const int TL84_3 = 1;
        private const int TL84_4 = 1;

        private const int U30_1 = 1;
        private const int U30_2 = 1;
        private const int U30_3 = 1;
        private const int U30_4 = 1;

        private const int TAGID = 0;
        private const int LEN = 1;
        private const int CMD_ID = 2;
        private const int HMI_ID = 3;
        private const int DATA = 4;
        private const int FREQ = 4;
        private const int STEP = 6;
        private const int AUTO_START_FREQ = 4;           // 2 bytes
        private const int AUTO_GOHOME_FREQ = 6;    // 2 bytes
        private const int AUTO_STEPS = 8;                       // 4 bytes
        private const int AUTO_TIME = 12;                      // 4 bytes
        private const int STEP_HOME_ACT = 4;              // 1 byte
        private const int STEP_HOME_FREQ = 5;           // 2 bytes
        private const int STEP_HOME_STEPS = 7;         // 4 bytes

        private const int STATE_DATA = 4;

        //Data Length
        private const int PING_LEN = 0x05;
        private const int SETID_LEN = 0x06;
        private const int READ_MOTOR_PARA_LEN = 0x06;
        private const int WRITE_MOTOR_PARA_LEN = 0x0A;
        private const int SAVE_DATA_LEN = 0x05;
        private const int STATE_LEN = 0x05;
        private const int RESTART_LEN = 0x05;
        private const int IO_STATUS_LEN = 0x06;
        private const int SETDO_LEN = 0x06;
        private const int MOTOR_MOVE_LEN = 0x06;
        private const int MOTOR_EMERG_LEN = 0x07;
        private const int SET_VOLT_LEN = 0x06;
        private const int READ_VOLT_LEN = 0x05;

        #endregion

        #region Public Parameter
        public byte[] rcvbuff = new byte[256];
        public static string debugSend_String = string.Empty;
        public static string debugReceive_String = string.Empty;
        public byte present_state = 0x03;
        public bool ping = false;

        //  Motor CMD ID
        public const byte PING = 0x00;
        public const byte SETID = 0x01;
        public const byte READ_MOTOR_PARA = 0x02;
        public const byte WRITE_MOTOR_PAPA = 0x03;
        public const byte SAVE_DATA = 0x04;
        public const byte STATE = 0x05;
        public const byte RESTART = 0x06;
        public const byte IO_STATUS = 0x07;
        public const byte SETDO = 0x08;
        public const byte MOTOR_MOVE = 0x09;
        public const byte MOTOR_EMERG = 0x0A;

        //  Light CMD ID
        public const byte SET_VOLT = 0x0B;
        public const byte READ_VOLT = 0x0C;

        //  Motor Param
        private const int MOTOR_FREQ = 10;
        private const int MOTOR_ACC = 10;

        private const int MOTOR_REL = 0x00;
        private const int MOTOR_ABS = 0x01;

        //String Command
        private const int CMD = 0;
        private const int TARGET = 1;
        private const int PARAM = 2;
        #endregion

        #region Class

        #endregion

        #region 接收指令(Hex)        
        public void GetCmd()
        {
            while (rcvbuff[0] != 0xF9)
            {
                if (rcvbuff[0] == 0)
                    break;
                Array.Copy(rcvbuff, 1, rcvbuff, 0, rcvbuff.Length - 1);                                                                     // 向左移1位
            }
            //debugReceive_String += BitConverter.ToString(rcvbuff);
            if (rcvbuff[0] == 0xF9)                                                                                                                                 //  比對TAG ID
            {
                if (rcvbuff[1] > 0 && rcvbuff[1] < 11)                                                                                                  //   比對CMD LENGTH範圍
                {
                    int cmd_len = rcvbuff[1];
                    byte[] cmd_buff = new byte[cmd_len];
                    Array.Copy(rcvbuff, 0, cmd_buff, 0, cmd_len);                                                                             //   取出CMD


                    if (rcvbuff[cmd_len - 1] == checkCRC(cmd_buff, cmd_len))                                                    //   比對CRC Check
                    {
                        AnalyzeCmd(cmd_buff, cmd_buff.Length);                                                                              //   分析CMD

                        Array.Clear(AckCheck, 0, AckCheck.Length);
                        Array.Copy(cmd_buff, 0, AckCheck, 0, cmd_buff.Length);

                        Array.Copy(rcvbuff, cmd_len, rcvbuff, 0, rcvbuff.Length - cmd_len);                                 //   從buffer中移除取出之cmd訊息

                        //debugReceive_String += BitConverter.ToString(cmd_buff, 0, cmd_len);
                        //debugReceive_String += BitConverter.ToString(rcvbuff, 0, rcvbuff.Length);
                    }
                    else
                    {
                        //若CRC Check錯誤
                        debugReceive_String += "CRC Check 錯誤!!\r\n";
                        debugReceive_String += "Receive Message: " + BitConverter.ToString(cmd_buff, 0, cmd_len) + "\r\n";
                        Array.Copy(rcvbuff, cmd_len, rcvbuff, 0, rcvbuff.Length - cmd_len);                                  // 向左移cmd length位

                    }
                }
                else
                {
                    //若CMD LENGTH錯誤
                    debugReceive_String += "CMD 長度錯誤!!\r\n";
                    debugReceive_String += "Receive Message: " + BitConverter.ToString(rcvbuff, 0, 2) + "\r\n";
                    Array.Copy(rcvbuff, 2, rcvbuff, 0, rcvbuff.Length - 2);                                                                 // 向左移2位
                }
            }
            else
            {
                //若TAG ID錯誤
                debugReceive_String += "TAG ID 錯誤!!\r\n";
                debugReceive_String += "Receive Message: " + BitConverter.ToString(rcvbuff, 0, 1) + "\r\n";
                Array.Copy(rcvbuff, 1, rcvbuff, 0, rcvbuff.Length - 1);                                                                     // 向左移1位
            }
        }

        public void AnalyzeCmd(byte[] rcvData, int rcvData_len)
        {
            switch (rcvData[CMD_ID])
            {
                case PING:
                    debugReceive_String += "Receive = Ping Ack\r\n";
                    ping = true;
                    break;

                case SETID:
                    debugReceive_String += "Receive = Set ID Ack\r\n";
                    break;

                case READ_MOTOR_PARA:
                    debugReceive_String += "Receive = Read Motor Parameter Ack\r\n";
                    int freq = 0;
                    int acc = 0;
                    string motor_axis = string.Empty;
                    string motor_freq;
                    string motor_acc;

                    //MOTOR AXIS
                    if (rcvData[DATA] == 0) motor_axis = "Axis: X ";
                    else if (rcvData[DATA] == 1) motor_axis = "Axis: Y ";
                    else if (rcvData[DATA] == 2) motor_axis = "Axis: Z ";

                    //MOTOR FREQ    
                    freq = (rcvData[DATA + 2] << 8 | rcvData[DATA + 1]);
                    motor_freq = "Freq: " + freq.ToString();

                    //MOTOR ACCELERATION
                    acc = (rcvData[DATA + 3] << 8 + rcvData[DATA + 4]);
                    motor_acc = "Acceleration: " + acc.ToString();

                    debugReceive_String += motor_axis + motor_freq + motor_acc + "\r\n";
                    break;

                case WRITE_MOTOR_PAPA:
                    debugReceive_String += "Receive = Auto Ack\r\n";
                    string write_state = string.Empty;

                    if (rcvData[DATA] == 0)
                        write_state = "Success\r\n";
                    else if (rcvData[DATA] == 1)
                        write_state = "Wrong Data Length\r\n";
                    else if (rcvData[DATA] == 2)
                        write_state = "Wrong Motor Number\r\n";

                    debugReceive_String += "Write Result: " + write_state + "\r\n";

                    break;

                case SAVE_DATA:
                    debugReceive_String += "Receive = Save Data Ack\r\n";
                    break;

                case STATE:
                    present_state = rcvData[DATA];
                    debugReceive_String += "Receive = State Ack\r\n";
                    break;

                case RESTART:
                    debugReceive_String += "Receive = RESTART Ack\r\n";
                    break;

                case IO_STATUS:
                    ///////////////////////////////////////////////////////
                    debugReceive_String += "Receive = IO STATUS Ack\r\n";
                    break;

                case SETDO:
                    debugReceive_String += "Receive = SET DO Ack\r\n";
                    break;

                case MOTOR_MOVE:
                    debugReceive_String += "Receive = MOTOR MOVE Ack\r\n";
                    break;

                case MOTOR_EMERG:
                    debugReceive_String += "Receive = MOTOR EMERGENCY Ack\r\n";
                    string error_axis = string.Empty;
                    string UL_limit = string.Empty;    //Upper = 0, Lower =1

                    //ERROR AXIS
                    if (rcvData[DATA] == 0)
                        error_axis = "X axis ";
                    else if (rcvData[DATA] == 1)
                        error_axis = "Y axis ";
                    else if (rcvData[DATA] == 2)
                        error_axis = "Z axis  ";

                    //ERROR SENSOR
                    if (rcvData[DATA + 1] == 0)
                        UL_limit = "Upper Limit ";
                    else if (rcvData[DATA + 1] == 1)
                        UL_limit = "Lower Limit ";

                    debugReceive_String += "Error: " + error_axis + UL_limit + "\r\n";
                    break;

                case SET_VOLT:

                    debugReceive_String += "Receive = SET VOLTAGE Ack\r\n";
                    break;

                case READ_VOLT:
                    debugReceive_String += "Receive = READ VOLTAGE Ack\r\n";
                    int read_volt = (int)rcvData[DATA];
                    debugReceive_String += "Read Voltage = " + read_volt + "\r\n";
                    break;

            }
            debugReceive_String += "Receive Message: " + BitConverter.ToString(rcvData, 0, rcvData_len) + "\r\n";
        }

        private bool AnalyzeAck(byte[] rcvData, byte sendCMD, byte sendHMI)
        {
            if (rcvData[CMD_ID] == sendCMD)
            {
                if (rcvData[HMI_ID] == sendHMI)
                {
                    return true;
                }
                else
                {
                    //PrintRcvDebugString("Ack HMI_ID Error");
                    //PrintRcvDebugString(BitConverter.ToString(rcvData));
                    return false;
                }
            }
            else
            {
                //PrintRcvDebugString("Ack CMD_ID Error");
                return false;
            }
        }

        private bool CheckAck(byte[] rcvData, byte sendCMD, byte sendHMI)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            for (int i = 0; i < 100000000; i++) // nEntries is typically more than 500,000
            {
                if (AnalyzeAck(rcvData, sendCMD, sendHMI))
                {
                    //PrintRcvDebugString(("Ack Msg: " + BitConverter.ToString(rcvData)));
                    PrintRcvDebugString(sendHMI.ToString() + " Done");
                    return true;
                }

                if (sw.ElapsedMilliseconds > 2000)
                {
                    PrintRcvDebugString("TImeOut");
                    break;
                }
            }

            //PrintRcvDebugString("StopWatch Time: " + sw.ElapsedMilliseconds.ToString());
            debugReceive_String += sendHMI.ToString() + " Not Responding\r\n";
            Array.Clear(AckCheck, 0, AckCheck.Length);
            sw.Stop();
            return false;
        }

        #endregion


        #region 接收指令(String)
        public bool Command_Task(string rcvString)
        {
            //解析輸入指令 
            string[] cmd = rcvString.Split(' ', (char)StringSplitOptions.RemoveEmptyEntries);
            if (cmd[CMD].Equals("set"))
            {
                if (!string.IsNullOrWhiteSpace(cmd[PARAM]))
                {
                    return set_Cmd(cmd[TARGET].ToString(), int.Parse(cmd[PARAM]));
                }
                else
                {
                    return false;
                }
            }
            else if (cmd[CMD].Equals("get"))
            {
                return false;
                //return getCmd(cmd[TARGET]);
            }
            else if (cmd[CMD].Equals("search"))
            {
                return searchHome();
            }
            else if (cmd[CMD].Equals("stop"))
            {
                return false; //stop();
            }
            else if (cmd[CMD].Equals("Ping"))
            {
                return pingAll();
            }
            else
                return false;
        }
        /////////////SET/////////////
        public bool setX(int dist)
        {
            int steps = dist;   //  dist轉換
            SendData(Port: CommonSerial.OutputPort, hmiid: XYZ_MOTOR, cmd: MOTOR_MOVE, motor_axis: X_AXIS, motor_mode: MOTOR_ABS, acc: MOTOR_ACC, freq: MOTOR_FREQ, steps: steps);
            if (!CheckAck(AckCheck, MOTOR_MOVE, XYZ_MOTOR))
                return false;
            else
            {
                debugReceive_String += "Set X Done\r\n";
                return true;
            }
        }
        private bool setY(int dist)
        {
            int steps = dist;
            SendData(Port: CommonSerial.OutputPort, hmiid: XYZ_MOTOR, cmd: MOTOR_MOVE, motor_axis: Y_AXIS, motor_mode: MOTOR_ABS, acc: MOTOR_ACC, freq: MOTOR_FREQ, steps: steps);
            if (!CheckAck(AckCheck, MOTOR_MOVE, XYZ_MOTOR))
                return false;
            else
            {
                debugReceive_String += "Set Y Done\r\n";
                return true;
            }
        }
        private bool setZ(int dist)
        {
            int steps = dist;
            SendData(Port: CommonSerial.OutputPort, hmiid: XYZ_MOTOR, cmd: MOTOR_MOVE, motor_axis: Z_AXIS, motor_mode: MOTOR_ABS, acc: MOTOR_ACC, freq: MOTOR_FREQ, steps: steps);
            if (!CheckAck(AckCheck, MOTOR_MOVE, XYZ_MOTOR))
                return false;
            else
            {
                debugReceive_String += "Set Z Done\r\n";
                return true;
            }
        }

        public bool searchHome()
        {
            //Search Sensor
            return false;
        }

        public bool gohome()
        {
            return true;
        }

        public void stop()  //是否需等待Ack??
        {
            SendData(hmiid: XYZ_MOTOR, cmd: MOTOR_MOVE, motor_axis: X_AXIS, motor_mode: MOTOR_ABS, acc: 0, freq: 0, steps: 0);
            //Thread.Sleep(100);
            //SendData(hmiid: XYZ_MOTOR, cmd: MOTOR_MOVE, motor_axis: Y_AXIS, motor_mode: MOTOR_ABS, acc: 0, freq: 0, steps: 0);
            //Thread.Sleep(100);
            //SendData(hmiid: XYZ_MOTOR, cmd: MOTOR_MOVE, motor_axis: Z_AXIS, motor_mode: MOTOR_ABS, acc: 0, freq: 0, steps: 0);
        }
        private bool setA(int percent)
        {
            int steps = percent;    //  dist轉換
            SendData(Port: CommonSerial.OutputPort, hmiid: LEFT_CONTROL, cmd: MOTOR_MOVE, motor_axis: LEFT_A_VR, motor_mode: MOTOR_ABS, acc: MOTOR_ACC, freq: MOTOR_FREQ, steps: steps);
            if (!CheckAck(AckCheck, MOTOR_MOVE, LEFT_CONTROL))
                return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: RIGHT_CONTROL, cmd: MOTOR_MOVE, motor_axis: RIGHT_A_VR, motor_mode: MOTOR_ABS, acc: MOTOR_ACC, freq: MOTOR_FREQ, steps: steps);
            if (!CheckAck(AckCheck, MOTOR_MOVE, RIGHT_CONTROL))
                return false;
            debugReceive_String += "Set A Done\r\n";
            return true;
        }
        private bool setHZ(int percent)
        {
            int steps = percent;    //  dist轉換
            SendData(Port: CommonSerial.OutputPort, hmiid: RIGHT_CONTROL, cmd: MOTOR_MOVE, motor_axis: LEFT_HZ_VR, motor_mode: MOTOR_ABS, acc: MOTOR_ACC, freq: MOTOR_FREQ, steps: steps);
            if (!CheckAck(AckCheck, MOTOR_MOVE, LEFT_CONTROL))
                return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: RIGHT_CONTROL, cmd: MOTOR_MOVE, motor_axis: RIGHT_HZ_VR, motor_mode: MOTOR_ABS, acc: MOTOR_ACC, freq: MOTOR_FREQ, steps: steps);
            if (!CheckAck(AckCheck, MOTOR_MOVE, RIGHT_CONTROL))
                return false;
            debugReceive_String += "Set HZ Done\r\n";
            return true;
        }
        private bool setCWF(int percent)
        {
            //SendData(Port: CommonSerial.OutputPort, hmiid: CWF_1, cmd: SET_VOLT, setVolt_per: percent);
            //if (!CheckAck(AckCheck, SET_VOLT, CWF_1)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: CWF_2, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, CWF_2)) return false;
            //SendData(Port: CommonSerial.OutputPort, hmiid: CWF_3, cmd: SET_VOLT, setVolt_per: percent);
            //if (!CheckAck(AckCheck, SET_VOLT, CWF_3)) return false;
            //SendData(Port: CommonSerial.OutputPort, hmiid: CWF_4, cmd: SET_VOLT, setVolt_per: percent);
            //if (!CheckAck(AckCheck, SET_VOLT, CWF_4)) return false;
            debugReceive_String += "Set CWF Done\r\n";
            return true;
        }
        private bool setD65(int percent)
        {
            SendData(Port: CommonSerial.OutputPort, hmiid: D65_1, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, D65_1)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: D65_2, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, D65_2)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: D65_3, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, D65_3)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: D65_4, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, D65_4)) return false;
            debugReceive_String += "Set D65 Done\r\n";
            return true;
        }
        private bool setTL84(int percent)
        {
            SendData(Port: CommonSerial.OutputPort, hmiid: TL84_1, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, TL84_1)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: TL84_2, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, TL84_2)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: TL84_3, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, TL84_3)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: TL84_4, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, TL84_4)) return false;
            debugReceive_String += "Set TL84 Done\r\n";
            return true;
        }
        private bool setU30(int percent)
        {
            SendData(Port: CommonSerial.OutputPort, hmiid: U30_1, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, U30_1)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: U30_2, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, U30_2)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: U30_3, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, U30_3)) return false;
            SendData(Port: CommonSerial.OutputPort, hmiid: U30_4, cmd: SET_VOLT, setVolt_per: percent);
            if (!CheckAck(AckCheck, SET_VOLT, U30_4)) return false;
            debugReceive_String += "Set U30 Done\r\n";
            return true;
        }

        //旋轉燈箱
        private void rotate()
        {

        }

        /////////////GET/////////////  
        public byte[] getX()
        {
            return SendData(hmiid: XYZ_MOTOR, cmd: READ_MOTOR_PARA, motor_axis: X_AXIS);
        }
        private byte[] getY()
        {
            return SendData(hmiid: XYZ_MOTOR, cmd: READ_MOTOR_PARA, motor_axis: Y_AXIS);
        }
        private byte[] getZ()
        {
            return SendData(hmiid: XYZ_MOTOR, cmd: READ_MOTOR_PARA, motor_axis: X_AXIS);
        }
        private void getA()
        {

        }
        private void getHZ()
        {

        }
        private byte[] getCWF()
        {
            return SendData(hmiid: CWF_1, cmd: READ_VOLT);
        }
        private byte[] getD65()
        {
            return SendData(hmiid: D65_1, cmd: READ_VOLT);
        }
        private byte[] getTL84()
        {
            return SendData(hmiid: TL84_1, cmd: READ_VOLT);
        }
        private byte[] getU30()
        {
            return SendData(hmiid: U30_1, cmd: READ_VOLT);
        }

        public byte[] get_Cmd(string target)
        {
            switch (target)
            {
                case "X":
                    return getX();

                //case "Y":
                //    return getY();

                //case "Z":
                //    return getZ();

                case "A":
                    return null; //getA();

                case "HZ":
                    return null; //getHZ();

                case "CWF":
                    return getCWF();

                case "D65":
                    return getD65();

                case "TL84":
                    return getTL84();

                case "U30":
                    return getU30();

                default:
                    return null;
            }
        }

        public bool set_Cmd(string target, int data)
        {
            switch (target)
            {
                case "X":
                    return setX(data);

                //case "Y":
                //    return setY(data);

                //case "Z":
                //    return setZ(data);

                case "A":
                    return setA(data);
                case "HZ":
                    return setHZ(data);

                case "CWF":
                    return setCWF(data);

                case "D65":
                    return setD65(data);

                case "TL84":
                    return setTL84(data);

                case "U30":
                    return setU30(data);

                default:
                    return false;
            }
        }
        #endregion


        #region 傳送指令
        public void SendData(
                                                 SerialPort Port,
                                                 byte hmiid,
                                                 byte cmd,
                                                 byte setid = 0,
                                                 byte motor_axis = 0,
                                                 int acc = 0,
                                                 int io = 0,
                                                 int motor_mode = 0,
                                                 int freq = 0,
                                                 int steps = 0,
                                                 int setVolt_per = 0
                                                )
        {
            Thread.Sleep(10);
            sendData[TAGID] = 0xF1;
            sendData[HMI_ID] = hmiid;
            switch (cmd)
            {
                case PING:
                    sendData[CMD_ID] = PING;
                    sendData[LEN] = PING_LEN;
                    break;

                case SETID:
                    sendData[LEN] = SETID_LEN;
                    sendData[CMD_ID] = SETID;
                    sendData[DATA] = setid;
                    break;

                case READ_MOTOR_PARA:
                    sendData[CMD_ID] = READ_MOTOR_PARA;
                    sendData[LEN] = READ_MOTOR_PARA_LEN;
                    sendData[DATA] = motor_axis;
                    break;

                case WRITE_MOTOR_PAPA:
                    sendData[LEN] = WRITE_MOTOR_PARA_LEN;
                    sendData[CMD_ID] = WRITE_MOTOR_PAPA;
                    //MOTOR AXIS
                    sendData[DATA] = motor_axis;
                    //FREQ
                    sendData[DATA + 1] = (byte)(freq >> 8);
                    sendData[DATA + 2] = (byte)(freq & 0xFF);
                    //ACCELERATION
                    sendData[DATA + 3] = (byte)(acc >> 8);
                    sendData[DATA + 4] = (byte)(acc & 0xFF);
                    break;

                case SAVE_DATA:
                    sendData[CMD_ID] = SAVE_DATA;
                    sendData[LEN] = SAVE_DATA_LEN;
                    break;

                case STATE:
                    sendData[CMD_ID] = STATE;
                    sendData[LEN] = STATE_LEN;
                    break;

                case RESTART:
                    sendData[CMD_ID] = RESTART;
                    sendData[LEN] = RESTART_LEN;
                    break;

                case IO_STATUS:
                    sendData[CMD_ID] = IO_STATUS;
                    sendData[LEN] = IO_STATUS_LEN;
                    sendData[DATA] = (byte)io;
                    break;

                case SETDO:
                    sendData[CMD_ID] = SETDO;
                    sendData[LEN] = SETDO_LEN;
                    //DI = 0 , DO = 1
                    sendData[DATA] = (byte)io;

                    break;

                case MOTOR_MOVE:
                    //steps = Convert.ToUInt32(CountStep(deg, res));
                    sendData[CMD_ID] = MOTOR_MOVE;
                    sendData[LEN] = MOTOR_MOVE_LEN;
                    //MOTOR MODE
                    sendData[DATA] = (byte)motor_mode;
                    //MOTOR STEPS
                    sendData[DATA + 1] = (byte)((steps >> (3 - 0) * 8) & 0xff);
                    sendData[DATA + 2] = (byte)((steps >> (3 - 1) * 8) & 0xff);
                    sendData[DATA + 3] = (byte)((steps >> (3 - 2) * 8) & 0xff);
                    sendData[DATA + 4] = (byte)((steps >> (3 - 3) * 8) & 0xff);
                    break;

                case MOTOR_EMERG:
                    sendData[CMD_ID] = MOTOR_EMERG;
                    sendData[LEN] = MOTOR_EMERG_LEN;
                    break;

                case SET_VOLT:
                    sendData[CMD_ID] = SET_VOLT;
                    sendData[LEN] = SET_VOLT_LEN;
                    sendData[DATA] = (byte)setVolt_per;
                    break;

                case READ_VOLT:
                    sendData[CMD_ID] = READ_VOLT;
                    sendData[LEN] = READ_VOLT_LEN;
                    break;
            }
            sendData[sendData[LEN] - 1] = checkCRC(sendData, sendData[LEN]);
            SerialSend(Port, sendData, sendData[LEN]);
            debugSend_String += "Send: " + BitConverter.ToString(sendData, 0, sendData[LEN]) + "\r\n";
        }


        private byte[] SendData(
                                                 byte hmiid,
                                                 byte cmd,
                                                 byte setid = 0,
                                                 byte motor_axis = 0,
                                                 int io = 0,
                                                 int motor_mode = 0,
                                                 int acc = 0,
                                                 int freq = 0,
                                                 int steps = 0,
                                                 int setVolt_per = 0
                                                )
        {
            byte[] sendData = new byte[128];
            Thread.Sleep(10);
            sendData[TAGID] = 0xF1;
            sendData[HMI_ID] = hmiid;
            switch (cmd)
            {
                case PING:
                    sendData[CMD_ID] = PING;
                    sendData[LEN] = PING_LEN;
                    break;

                case SETID:
                    sendData[LEN] = SETID_LEN;
                    sendData[CMD_ID] = SETID;
                    sendData[DATA] = setid;
                    break;

                case READ_MOTOR_PARA:
                    sendData[CMD_ID] = READ_MOTOR_PARA;
                    sendData[LEN] = READ_MOTOR_PARA_LEN;
                    sendData[DATA] = motor_axis;
                    break;

                case WRITE_MOTOR_PAPA:
                    sendData[LEN] = WRITE_MOTOR_PARA_LEN;
                    sendData[CMD_ID] = WRITE_MOTOR_PAPA;
                    //MOTOR AXIS
                    sendData[DATA] = motor_axis;
                    //FREQ
                    sendData[DATA + 1] = (byte)(freq >> 8);
                    sendData[DATA + 2] = (byte)(freq & 0xFF);
                    //ACCELERATION
                    sendData[DATA + 3] = (byte)(acc >> 8);
                    sendData[DATA + 4] = (byte)(acc & 0xFF);
                    break;

                case SAVE_DATA:
                    sendData[CMD_ID] = SAVE_DATA;
                    sendData[LEN] = SAVE_DATA_LEN;
                    break;

                case STATE:
                    sendData[CMD_ID] = STATE;
                    sendData[LEN] = STATE_LEN;
                    break;

                case RESTART:
                    sendData[CMD_ID] = RESTART;
                    sendData[LEN] = RESTART_LEN;
                    break;

                case IO_STATUS:
                    sendData[CMD_ID] = IO_STATUS;
                    sendData[LEN] = IO_STATUS_LEN;
                    sendData[DATA] = (byte)io;
                    break;

                case SETDO:
                    sendData[CMD_ID] = SETDO;
                    sendData[LEN] = SETDO_LEN;
                    //DI = 0 , DO = 1
                    sendData[DATA] = (byte)io;

                    break;

                case MOTOR_MOVE:
                    //steps = Convert.ToUInt32(CountStep(deg, res));
                    sendData[CMD_ID] = MOTOR_MOVE;
                    sendData[LEN] = MOTOR_MOVE_LEN;
                    //MOTOR MODE
                    sendData[DATA] = (byte)motor_mode;
                    //MOTOR STEPS
                    sendData[DATA + 1] = (byte)((steps >> (3 - 0) * 8) & 0xff);
                    sendData[DATA + 2] = (byte)((steps >> (3 - 1) * 8) & 0xff);
                    sendData[DATA + 3] = (byte)((steps >> (3 - 2) * 8) & 0xff);
                    sendData[DATA + 4] = (byte)((steps >> (3 - 3) * 8) & 0xff);
                    break;

                case MOTOR_EMERG:
                    sendData[CMD_ID] = MOTOR_EMERG;
                    sendData[LEN] = MOTOR_EMERG_LEN;
                    break;

                case SET_VOLT:
                    sendData[CMD_ID] = SET_VOLT;
                    sendData[LEN] = SET_VOLT_LEN;
                    sendData[DATA] = (byte)setVolt_per;
                    break;

                case READ_VOLT:
                    sendData[CMD_ID] = READ_VOLT;
                    sendData[LEN] = READ_VOLT_LEN;
                    break;
            }
            sendData[sendData[LEN] - 1] = checkCRC(sendData, sendData[LEN]);
            return CutTail(sendData);
        }

        public void SerialSend(SerialPort Port, byte[] msg, int msg_len)
        {
            if (Port.IsOpen && main.isReceiving == false)
            {
                Thread SendData = new Thread(
                    delegate ()
                    {
                        Port.Write(msg, 0, msg_len);
                    });
                SendData.Start();
            }
            else return;
        }

        #endregion


        #region 計算Func.

        private byte[] CutTail(byte[] byList)
        {
            int j = 0;
            byte[] tempb = null;
            for (int i = byList.Length - 1; i >= 0; i--)
            {
                if (byList[i] != 0x00 & j == 0)
                {
                    j = i;
                    if (tempb == null)
                    {
                        tempb = new byte[j + 1];
                    }

                    tempb[j] = byList[i];
                    j--;
                }
                else
                {
                    if (tempb != null)
                    {
                        tempb[j] = byList[i];
                        j--;
                    }
                }
            }
            return tempb;
        }

        private byte[] bytesTrimEnd(byte[] bytes)
        {
            List<byte> list = bytes.ToList();
            for (int i = bytes.Length - 1; i >= 0; i--)
            {
                if (bytes[i] == 0x00)
                {
                    list.RemoveAt(i);
                }
                else
                {
                    break;
                }
            }
            return list.ToArray();
        }

        /// <summary>
        /// 計算PWM頻率
        /// </summary>
        /// <param name="rpm"></param>
        /// <param name="res"></param>
        /// <returns></returns>
        public int CountFreq(float rpm, int res)
        {
            int freq = (int)(Math.Round(rpm / 60 * res));
            if (freq > 10667 || freq < 1067)
                return -1;
            else
                return freq;
        }

        private byte checkCRC(byte[] bytes, int length)
        {
            byte cRc = 0x00;
            for (int i = 0; i < (length - 1); i++)
            {
                cRc -= bytes[i];
            }
            return cRc;
        }

        /// <summary>
        /// 計算角度Pulse
        /// </summary>
        /// <param name="deg"></param>
        /// <param name="res"></param>
        /// <returns></returns>
        public int CountStep(int deg, int res)
        {
            //double deg_OK = deg / 0.9;
            //if (deg_OK == Math.Floor(deg_OK))
            //    return (int)(res * 0.9 / 360 * deg_OK); // res/deg = 6400/360 = 16/0.9 每0.9度16個pulse
            //else
            //    return -1;

            int i = (deg - 4) / 9 + 1;
            double deg_OK;
            if (deg > 0 && deg < 5)
                deg_OK = 0.9 * deg;
            else
                deg_OK = 0.9 * (i + deg);

            // += deg_OK + "\r\n";
            deg_OK = deg_OK / 0.9;
            return (int)(res * 0.9 / 360 * deg_OK); // res/deg = 6400/360 = 16/0.9 每0.9度16個pulse
        }

        #endregion


        #region Timer
        public void wait(int milliseconds)
        {
            var timer1 = new System.Windows.Forms.Timer();
            if (milliseconds == 0 || milliseconds < 0) return;

            // Console.WriteLine("start wait timer");
            timer1.Interval = milliseconds;
            timer1.Enabled = true;
            timer1.Start();

            timer1.Tick += (s, e) =>
            {
                timer1.Enabled = false;
                timer1.Stop();
                // Console.WriteLine("stop wait timer");
            };

            while (timer1.Enabled)
            {

            }
        }
        #endregion


        #region Other Func
        public void PrintRcvDebugString(string debug)
        {
            debugReceive_String += debug + "\r\n";
        }
        public void PrintSendDebugString(string debug)
        {
            debugSend_String += debug + "\r\n";
        }

        public bool pingAll()
        {
            //Thread thread = new Thread(delegate ()
            //{
            for (int i = 1; i < 17; i++)
            {
                SendData(CommonSerial.OutputPort, (byte)i, RcvSend_Data.PING);
                if (!CheckAck(AckCheck, PING, (byte)i))
                {
                    //PrintRcvDebugString("HMI ID: " + i.ToString() + "Not Responding");
                }
                else
                {
                    //PrintRcvDebugString("HMI ID: " + i.ToString() + " OK");
                }
            }
            //});
            //thread.Start();
            return true;
            #endregion
        }
    }
}
